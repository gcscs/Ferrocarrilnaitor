package com.ferrocarrilnaitor

import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.util.Rational
import android.view.Surface
import android.os.Looper
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCaseGroup
import androidx.camera.core.ViewPort
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.io.File

/**
 * Flujo de foto en 3 pasos:
 * 0 = cámara (sacar foto), 1 = revisar (Repetir / OK), 2 = elegir los puntos (S | D) y guardar.
 */
@Composable
fun CameraFlow(h: ProjectHolder, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        BackHandler(onBack = onBack)
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Se necesita permiso de cámara")
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Conceder permiso") }
            TextButton(onClick = onBack) { Text("Volver") }
        }
        return
    }

    val temp = remember { File(ctx.cacheDir, "foto_temp.jpg") }
    var stage by remember { mutableIntStateOf(0) }
    var banner by remember { mutableStateOf<String?>(null) }

    when (stage) {
        0 -> CameraCapture(temp, banner, onBack) { banner = null; stage = 1 }
        1 -> PhotoReview(temp, onRetry = { stage = 0 }, onOk = { stage = 2 })
        else -> PointPicker(h, temp, onCancel = { stage = 1 }) { ids ->
            try {
                h.project.photoCounter++
                val name = "foto_%04d_%s.jpg".format(h.project.photoCounter, ids.joinToString("-"))
                val dest = h.photoFile(name)
                dest.parentFile?.mkdirs()
                temp.copyTo(dest, overwrite = true)
                temp.delete()
                h.project.points.filter { it.id in ids }.forEach { it.photos.add(name) }
                h.commit()
                Toast.makeText(ctx, "📷 Foto guardada en: ${ids.joinToString(", ")}", Toast.LENGTH_LONG).show()
                onBack()   // vuelve al menú con todos los puntos
            } catch (e: Exception) {
                banner = "Error al guardar la foto: ${e.message}"
                stage = 0
            }
        }
    }
}

@Composable
fun CameraCapture(temp: File, banner: String?, onBack: () -> Unit, onCaptured: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val activity = ctx as ComponentActivity
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var msg by remember { mutableStateOf(banner) }
    var busy by remember { mutableStateOf(false) }
    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
    }
    val previewView = remember { PreviewView(ctx) }

    DisposableEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            provider.unbindAll()
            // Viewport 1:1: la cámara captura ya en cuadrado (lo que ves en el visor es lo que se guarda)
            val rotation = previewView.display?.rotation ?: Surface.ROTATION_0
            val viewPort = ViewPort.Builder(Rational(1, 1), rotation)
                .setScaleType(ViewPort.FILL_CENTER).build()
            val group = UseCaseGroup.Builder()
                .setViewPort(viewPort)
                .addUseCase(preview)
                .addUseCase(imageCapture)
                .build()
            camera = provider.bindToLifecycle(activity, CameraSelector.DEFAULT_BACK_CAMERA, group)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { runCatching { future.get().unbindAll() } }
    }
    LaunchedEffect(msg) { if (msg != null) { delay(3000); msg = null } }

    val maxZoom = (camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f).coerceAtMost(10f)
    fun applyZoom(z: Float) {
        zoom = z.coerceIn(1f, maxZoom.coerceAtLeast(1f))
        camera?.cameraControl?.setZoomRatio(zoom)
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.align(Alignment.Center).fillMaxWidth().aspectRatio(1f).pointerInput(maxZoom) {
                detectTransformGestures { _, _, z, _ -> applyZoom(zoom * z) }
            }
        )
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Text("← Atrás", color = Color.White)
        }
        msg?.let {
            Text(it, color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp, start = 16.dp, end = 16.dp)
                    .background(Color(0xCC2E7D32)).padding(10.dp))
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            .background(Color(0xAA000000)).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            if (maxZoom > 1.05f) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Zoom ${"%.1f".format(zoom)}x", color = Color.White)
                    Slider(value = zoom, onValueChange = { applyZoom(it) },
                        valueRange = 1f..maxZoom, modifier = Modifier.weight(1f).padding(start = 8.dp))
                }
            }
            Button(enabled = !busy, onClick = {
                busy = true
                imageCapture.takePicture(
                    ImageCapture.OutputFileOptions.Builder(temp).build(),
                    ContextCompat.getMainExecutor(ctx),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                            // la foto ya sale cuadrada; solo se recorta si algún móvil no respeta el viewport
                            Thread {
                                val ok = cropToSquare(temp)
                                Handler(Looper.getMainLooper()).post {
                                    busy = false
                                    if (ok) onCaptured() else msg = "Error al recortar la foto"
                                }
                            }.start()
                        }
                        override fun onError(e: ImageCaptureException) {
                            busy = false
                            msg = "Error al sacar la foto: ${e.message}"
                        }
                    })
            }) { Text("📷  Sacar foto") }
        }
    }
}

@Composable
fun PhotoReview(temp: File, onRetry: () -> Unit, onOk: () -> Unit) {
    BackHandler(onBack = onRetry)
    Column(Modifier.fillMaxSize()) {
        Header("¿La foto está bien?", onRetry)
        Photo(temp, 1600, Modifier.weight(1f).fillMaxWidth(), ContentScale.Fit)
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onRetry, modifier = Modifier.weight(1f)) { Text("Repetir") }
            Button(onClick = onOk, modifier = Modifier.weight(1f)) { Text("OK") }
        }
    }
}

@Composable
fun PointPicker(h: ProjectHolder, temp: File, onCancel: () -> Unit, onSave: (List<String>) -> Unit) {
    BackHandler(onBack = onCancel)
    val selected = remember { mutableStateListOf<String>() }
    val s = h.project.points.filter { !it.isD }
    val d = h.project.points.filter { it.isD }
    Column(Modifier.fillMaxSize()) {
        Header("¿A qué puntos corresponde?", onCancel)
        Photo(temp, 500, Modifier.fillMaxWidth().height(150.dp), ContentScale.Crop)
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text("Estacionarios (S)", Modifier.weight(1f))
            Text("Dinámicos (D)", Modifier.weight(1f))
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            items(maxOf(s.size, d.size)) { i ->
                Row(Modifier.fillMaxWidth()) {
                    PickCell(s.getOrNull(i), selected, Modifier.weight(1f))
                    PickCell(d.getOrNull(i), selected, Modifier.weight(1f))
                }
            }
        }
        Button(
            enabled = selected.isNotEmpty(),
            onClick = { onSave(h.project.points.map { it.id }.filter { it in selected }) },
            modifier = Modifier.fillMaxWidth().padding(12.dp)
        ) { Text("Guardar foto en ${selected.size} punto(s)") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PickCell(p: Point?, selected: SnapshotStateList<String>, modifier: Modifier) {
    Box(modifier.padding(3.dp)) {
        if (p != null) {
            val on = p.id in selected
            val dark = isSystemInDarkTheme()
            // seleccionado: azul intenso + borde ámbar + ✔ (distinto del rojo/verde de completo/incompleto)
            val bg = if (on) (if (dark) Color(0xFF1E88E5) else Color(0xFF1565C0))
            else MaterialTheme.colorScheme.surfaceVariant
            val fg = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
            Card(
                modifier = Modifier.fillMaxWidth()
                    .clickable { if (on) selected.remove(p.id) else selected.add(p.id) },
                colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
                border = if (on) BorderStroke(3.dp, Color(0xFFFFC107)) else null
            ) {
                Text(
                    (if (on) "✔  " else "") + "${p.id}   📷${p.photos.size}",
                    modifier = Modifier.padding(14.dp),
                    fontWeight = if (on) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
