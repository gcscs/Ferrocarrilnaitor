package com.ferrocarrilnaitor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun Header(title: String, onBack: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) TextButton(onClick = onBack) { Text("←  Atrás") }
        Text(title, style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(start = if (onBack == null) 16.dp else 4.dp))
    }
}

/** Doble confirmación: primero "Continuar", luego "Sí, borrar". */
@Composable
fun DoubleConfirm(title: String, detail: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    var stage by remember { mutableIntStateOf(1) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (stage == 1) title else "¿Seguro?") },
        text = { Text(if (stage == 1) detail else "Esta acción no se puede deshacer.") },
        confirmButton = {
            TextButton(onClick = { if (stage == 1) stage = 2 else onConfirm() }) {
                Text(if (stage == 1) "Continuar" else "Sí, borrar")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

fun loadBitmap(file: File, max: Int): Bitmap? {
    if (!file.exists()) return null
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.path, bounds)
    var s = 1
    while (bounds.outWidth / (s * 2) >= max || bounds.outHeight / (s * 2) >= max) s *= 2
    val bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = s })
        ?: return null
    val deg = when (ExifInterface(file.path)
        .getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    return if (deg == 0f) bmp
    else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
}

@Composable
fun Photo(file: File, max: Int, modifier: Modifier, scale: ContentScale) {
    val bmp by produceState<Bitmap?>(null, file, file.lastModified()) {
        value = withContext(Dispatchers.IO) { runCatching { loadBitmap(file, max) }.getOrNull() }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, modifier, contentScale = scale)
    else Box(modifier.background(Color.LightGray))
}
