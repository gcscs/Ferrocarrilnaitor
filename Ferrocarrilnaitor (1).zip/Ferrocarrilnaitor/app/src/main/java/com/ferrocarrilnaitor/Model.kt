package com.ferrocarrilnaitor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Cómo se rellena una medición: nº de registro, valor manual en mT o simple check. */
enum class Mode { REGISTRO, VALOR, CHECK }

enum class Meter(val label: String, val mode: Mode) {
    SMP3("SMP-3", Mode.REGISTRO),
    EHP50F("EHP-50F", Mode.CHECK),
    ETM("ETM", Mode.VALOR)
}

/** Medición de un componente (AC o DC) en un punto. Los campos son estado de Compose. */
class Measure(
    initialDone: Boolean = false,       // CHECK (EHP-50F)
    initialRegistro: Int? = null,       // REGISTRO (SMP-3)
    initialValorMt: Double? = null      // VALOR (ETM), en mT
) {
    var done by mutableStateOf(initialDone)
    var registro by mutableStateOf(initialRegistro)
    var valorMt by mutableStateOf(initialValorMt)

    fun isMeasured(m: Meter) = when (m.mode) {
        Mode.REGISTRO -> registro != null
        Mode.CHECK -> done
        Mode.VALOR -> valorMt != null
    }

    fun clear() { done = false; registro = null; valorMt = null }

    fun describe(m: Meter): String = when (m.mode) {
        Mode.REGISTRO -> "registro ${registro ?: "-"}"
        Mode.CHECK -> "medido"
        Mode.VALOR -> "${valorMt ?: "-"} mT"
    }

    fun toJson() = JSONObject().apply {
        put("done", done)
        registro?.let { put("registro", it) }
        valorMt?.let { put("valorMt", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = Measure(
            initialDone = o.optBoolean("done", false),
            initialRegistro = if (o.has("registro")) o.getInt("registro") else null,
            initialValorMt = if (o.has("valorMt")) o.getDouble("valorMt") else null
        )
    }
}

class Point(
    val id: String,                     // D1, D2, S1...
    initialNotes: String = "",
    val ac: Measure = Measure(),
    val dc: Measure = Measure(),
    initialPhotos: List<String> = emptyList()
) {
    var notes by mutableStateOf(initialNotes)
    val photos = mutableStateListOf<String>().also { it.addAll(initialPhotos) }

    val isD get() = id.startsWith("D")

    fun complete(p: Project) = ac.isMeasured(p.acMeter) && dc.isMeasured(p.dcMeter) && photos.isNotEmpty()

    fun toJson() = JSONObject().apply {
        put("id", id)
        put("notes", notes)
        put("ac", ac.toJson())
        put("dc", dc.toJson())
        put("photos", JSONArray(photos.toList()))
    }

    companion object {
        fun fromJson(o: JSONObject): Point {
            val ph = mutableListOf<String>()
            o.optJSONArray("photos")?.let { for (i in 0 until it.length()) ph.add(it.getString(i)) }
            return Point(
                id = o.getString("id"),
                initialNotes = o.optString("notes", ""),
                ac = Measure.fromJson(o.getJSONObject("ac")),
                dc = Measure.fromJson(o.getJSONObject("dc")),
                initialPhotos = ph
            )
        }
    }
}

class Project(
    val name: String,
    val acMeter: Meter,                 // SMP3 o EHP50F
    val dcMeter: Meter,                 // SMP3 o ETM
    initialSmpNext: Int,                // siguiente nº de registro SMP-3
    val folder: String,                 // carpeta del PC (instrumento con check)
    val created: String,
    val points: MutableList<Point>,
    var photoCounter: Int = 0,
    initialGeneralNotes: String = ""
) {
    var smpNext by mutableIntStateOf(initialSmpNext)
    var generalNotes by mutableStateOf(initialGeneralNotes)

    val usesSmp get() = acMeter.mode == Mode.REGISTRO || dcMeter.mode == Mode.REGISTRO
    val usesFolder get() = acMeter.mode == Mode.CHECK || dcMeter.mode == Mode.CHECK

    fun toJson() = JSONObject().apply {
        put("name", name)
        put("ac", acMeter.name)
        put("dc", dcMeter.name)
        put("smpNext", smpNext)
        put("folder", folder)
        put("created", created)
        put("photoCounter", photoCounter)
        put("generalNotes", generalNotes)
        put("points", JSONArray().also { a -> points.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val pts = mutableListOf<Point>()
            val a = o.getJSONArray("points")
            for (i in 0 until a.length()) pts.add(Point.fromJson(a.getJSONObject(i)))
            return Project(
                name = o.getString("name"),
                acMeter = Meter.valueOf(o.getString("ac")),
                dcMeter = Meter.valueOf(o.getString("dc")),
                initialSmpNext = o.optInt("smpNext", 1),
                folder = o.optString("folder", ""),
                created = o.optString("created", ""),
                points = pts,
                photoCounter = o.optInt("photoCounter", 0),
                initialGeneralNotes = o.optString("generalNotes", "")
            )
        }
    }
}
