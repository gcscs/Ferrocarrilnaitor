package com.ferrocarrilnaitor

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Medición recibida en un paquete (comp = "AC" o "DC"). */
class InMeasure(val comp: String, val height: Int, val m: Measure)

class InPoint(
    val id: String, val type: PointType, val notes: String,
    val measures: List<InMeasure>, val photos: List<String>
)

class ImportPackage(val file: File, val source: String, val ac: Meter, val dc: Meter, val points: List<InPoint>)

/** Dato que ya está rellenado aquí con un valor distinto al del paquete (una medición o las notas). */
class Conflict(
    val key: String,
    val label: String,
    val localText: String,
    val incomingText: String,
    val applyIncoming: () -> Unit
) {
    var useIncoming by mutableStateOf(false)     // por defecto prevalece la local
}

class ImportPlan(
    val newMeasures: Int,
    val newNotes: Int,
    val newPhotos: Int,
    val conflicts: List<Conflict>,
    val skipped: List<String>,
    val lastRegistro: Int? = null      // mayor registro SMP-3 de las mediciones del paquete
)

/** Paquete de proyecto completo (estructura, mediciones, notas y fotos). */
class ProjectPackage(val file: File, val name: String, val points: Int, val photos: Int)

object Share {
    private const val FORMAT = "ferrocarrilnaitor-export"

    // ---------------------------------------------------------------- exportar

    /** Crea un zip con datos.json (mediciones rellenadas) y las fotos de los puntos seleccionados. */
    fun export(h: ProjectHolder, ids: Set<String>): File {
        val p = h.project
        val pts = p.points.filter { it.id in ids }
        val dir = File(h.dir, "exportaciones").also { it.mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(dir, "${p.name}_export_$stamp.zip")

        fun measures(pt: Point, list: List<Measure>, meter: Meter) = JSONArray().also { a ->
            list.forEachIndexed { i, m ->
                if (m.isMeasured(meter)) a.put(m.toJson().put("h", pt.type.heights[i]))
            }
        }

        val json = JSONObject().apply {
            put("formato", FORMAT)
            put("version", 1)
            put("proyecto", p.name)
            put("ac", p.acMeter.name)
            put("dc", p.dcMeter.name)
            put("exportado", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
            put("puntos", JSONArray().also { arr ->
                pts.forEach { pt ->
                    arr.put(JSONObject().apply {
                        put("id", pt.id)
                        put("tipo", pt.type.name)
                        put("notas", pt.notes)
                        put("ac", measures(pt, pt.ac, p.acMeter))
                        put("dc", measures(pt, pt.dc, p.dcMeter))
                        put("fotos", JSONArray(pt.photos.toList()))
                    })
                }
            })
        }

        ZipOutputStream(FileOutputStream(out)).use { z ->
            z.putNextEntry(ZipEntry("datos.json"))
            z.write(json.toString(2).toByteArray())
            z.closeEntry()
            pts.flatMap { it.photos }.distinct().forEach { name ->
                val f = h.photoFile(name)
                if (f.exists()) {
                    z.putNextEntry(ZipEntry("fotos/$name"))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- importar

    class Prepared(val pkg: ImportPackage, val plan: ImportPlan)

    /** Lee el paquete elegido y calcula qué se añadiría y qué entra en conflicto. */
    fun prepare(ctx: Context, h: ProjectHolder, uri: Uri): Prepared {
        val tmp = File(ctx.cacheDir, "import_${System.currentTimeMillis()}.zip")
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("No se pudo abrir el archivo")
        input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        try {
            val pkg = readPackage(tmp)
            return Prepared(pkg, plan(h, pkg))
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    private fun readPackage(file: File): ImportPackage {
        var isProject = false
        val o: JSONObject? = try {
            ZipFile(file).use { z ->
                val e = z.getEntry("datos.json")
                if (e == null) { isProject = z.getEntry("paquete.json") != null; null }
                else JSONObject(z.getInputStream(e).bufferedReader().readText())
            }
        } catch (e: Exception) { null }
        if (o == null) throw IllegalArgumentException(
            if (isProject) "Este archivo es un proyecto completo: impórtalo desde el menú de proyectos (⬇ Importar proyecto)"
            else "El archivo no es un paquete de Ferrocarrilnaitor")
        if (o.optString("formato") != FORMAT)
            throw IllegalArgumentException("El archivo no es un paquete de Ferrocarrilnaitor")

        fun measures(arr: JSONArray?, comp: String): List<InMeasure> {
            val out = mutableListOf<InMeasure>()
            if (arr != null) for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                out.add(InMeasure(comp, m.getInt("h"), Measure.fromJson(m)))
            }
            return out
        }

        val pts = mutableListOf<InPoint>()
        val arr = o.getJSONArray("puntos")
        for (i in 0 until arr.length()) {
            val po = arr.getJSONObject(i)
            val ph = mutableListOf<String>()
            po.optJSONArray("fotos")?.let { for (k in 0 until it.length()) ph.add(it.getString(k)) }
            pts.add(InPoint(
                id = po.getString("id"),
                type = PointType.valueOf(po.getString("tipo")),
                notes = po.optString("notas", ""),
                measures = measures(po.optJSONArray("ac"), "AC") + measures(po.optJSONArray("dc"), "DC"),
                photos = ph
            ))
        }
        return ImportPackage(
            file = file,
            source = o.optString("proyecto", "?"),
            ac = Meter.valueOf(o.getString("ac")),
            dc = Meter.valueOf(o.getString("dc")),
            points = pts
        )
    }

    private fun sha256(i: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(8192)
        while (true) { val n = i.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** hash del contenido -> nombre de la foto que ya existe en el proyecto */
    private fun localHashes(h: ProjectHolder): MutableMap<String, String> {
        val map = mutableMapOf<String, String>()
        File(h.dir, "fotos").listFiles()?.forEach { f ->
            if (f.isFile) runCatching { f.inputStream().use { map[sha256(it)] = f.name } }
        }
        return map
    }

    /** Puntos del paquete que existen aquí con el mismo tipo; el resto se descartan con motivo. */
    private fun matching(p: Project, pkg: ImportPackage, skipped: MutableList<String>): List<Pair<InPoint, Point>> {
        val out = mutableListOf<Pair<InPoint, Point>>()
        for (ip in pkg.points) {
            val lp = p.points.firstOrNull { it.id == ip.id }
            when {
                lp == null -> skipped.add("${ip.id}: no existe en este proyecto")
                lp.type != ip.type -> skipped.add(
                    "${ip.id}: es de otro tipo (aquí ${lp.type.label}, en el paquete ${ip.type.label})")
                else -> out.add(ip to lp)
            }
        }
        return out
    }

    private fun short(t: String): String {
        val c = t.trim().replace("\n", " ")
        return "«" + c.take(100) + (if (c.length > 100) "…" else "") + "»"
    }

    private fun plan(h: ProjectHolder, pkg: ImportPackage): ImportPlan {
        val p = h.project
        if (pkg.ac != p.acMeter || pkg.dc != p.dcMeter) throw IllegalArgumentException(
            "El paquete usa otros instrumentos (AC ${pkg.ac.label}, DC ${pkg.dc.label}) " +
                    "y este proyecto usa AC ${p.acMeter.label}, DC ${p.dcMeter.label}")
        val skipped = mutableListOf<String>()
        val pairs = matching(p, pkg, skipped)
        val conflicts = mutableListOf<Conflict>()
        var newMeasures = 0
        var newNotes = 0
        var lastIn: Int? = null
        for ((ip, lp) in pairs) {
            for (im in ip.measures) {
                val idx = lp.type.heights.indexOf(im.height)
                if (idx < 0) continue
                val isAc = im.comp == "AC"
                val meter = if (isAc) p.acMeter else p.dcMeter
                val local = (if (isAc) lp.ac else lp.dc)[idx]
                im.m.registro?.let { lastIn = maxOf(lastIn ?: 0, it) }
                if (!local.isMeasured(meter)) newMeasures++
                else if (!local.sameAs(im.m, meter)) conflicts.add(Conflict(
                    key = "${lp.id}|${im.comp}|${im.height}",
                    label = "${lp.id} · ${im.comp} a ${im.height} cm",
                    localText = local.describe(meter),
                    incomingText = im.m.describe(meter),
                    applyIncoming = { local.copyFrom(im.m) }))
            }
            if (ip.notes.isNotBlank()) {
                if (lp.notes.isBlank()) newNotes++
                else if (lp.notes.trim() != ip.notes.trim()) conflicts.add(Conflict(
                    key = "${lp.id}|notas",
                    label = "${lp.id} · Notas",
                    localText = short(lp.notes),
                    incomingText = short(ip.notes),
                    applyIncoming = { lp.notes = ip.notes }))
            }
        }
        // fotos nuevas = fotos del paquete cuyo contenido no está ya en el proyecto
        val hashes = localHashes(h)
        var newPhotos = 0
        ZipFile(pkg.file).use { z ->
            pairs.flatMap { it.first.photos }.distinct().forEach { name ->
                val e = z.getEntry("fotos/$name")
                if (e != null && z.getInputStream(e).use { sha256(it) } !in hashes) newPhotos++
            }
        }
        return ImportPlan(newMeasures, newNotes, newPhotos, conflicts, skipped, lastIn)
    }

    /** Aplica el paquete: mediciones nuevas, conflictos según lo elegido y fotos nuevas. */
    fun apply(h: ProjectHolder, prep: Prepared) {
        val p = h.project
        val pkg = prep.pkg
        val pairs = matching(p, pkg, mutableListOf())

        for ((ip, lp) in pairs) {
            for (im in ip.measures) {
                val idx = lp.type.heights.indexOf(im.height)
                if (idx < 0) continue
                val isAc = im.comp == "AC"
                val meter = if (isAc) p.acMeter else p.dcMeter
                val local = (if (isAc) lp.ac else lp.dc)[idx]
                if (!local.isMeasured(meter)) local.copyFrom(im.m)     // vacío aquí: se rellena
            }
            if (lp.notes.isBlank() && ip.notes.isNotBlank()) lp.notes = ip.notes
        }
        // conflictos: solo se sobrescribe lo que el usuario eligió como "importada"
        prep.plan.conflicts.forEach { if (it.useIncoming) it.applyIncoming() }

        // SMP-3: el siguiente registro pasa a ser el último guardado (aquí o en el paquete) + 1
        if (p.usesSmp) {
            var last = 0
            p.points.forEach { pt ->
                if (p.acMeter.mode == Mode.REGISTRO) pt.ac.forEach { m -> m.registro?.let { last = maxOf(last, it) } }
                if (p.dcMeter.mode == Mode.REGISTRO) pt.dc.forEach { m -> m.registro?.let { last = maxOf(last, it) } }
            }
            prep.plan.lastRegistro?.let { last = maxOf(last, it) }
            if (last + 1 > p.smpNext) p.smpNext = last + 1
        }

        // fotos: se reutiliza la que ya exista con el mismo contenido; si no, se copia con nombre nuevo
        val hashes = localHashes(h)
        val refs = LinkedHashMap<String, MutableList<Point>>()
        for ((ip, lp) in pairs) ip.photos.forEach { refs.getOrPut(it) { mutableListOf() }.add(lp) }
        ZipFile(pkg.file).use { z ->
            for ((name, pts) in refs) {
                val e = z.getEntry("fotos/$name") ?: continue
                val hash = z.getInputStream(e).use { sha256(it) }
                var local = hashes[hash]
                if (local == null) {
                    p.photoCounter++
                    local = "foto_%04d_%s.jpg".format(p.photoCounter, pts.joinToString("-") { it.id })
                    val dest = h.photoFile(local)
                    dest.parentFile?.mkdirs()
                    z.getInputStream(e).use { i -> dest.outputStream().use { i.copyTo(it) } }
                    hashes[hash] = local
                }
                pts.forEach { if (local !in it.photos) it.photos.add(local) }
            }
        }
        h.commit()
        pkg.file.delete()
    }

    fun discard(prep: Prepared) { prep.pkg.file.delete() }

    // ---------------------------------------------------------- proyecto completo

    private const val FORMAT_PROJECT = "ferrocarrilnaitor-proyecto"

    /** Zip con todo el proyecto: estructura, mediciones, notas y fotos. */
    fun exportProject(dir: File): File {
        val out = File(File(dir, "exportaciones").also { it.mkdirs() },
            "${dir.name}_proyecto_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.zip")
        ZipOutputStream(FileOutputStream(out)).use { z ->
            z.putNextEntry(ZipEntry("paquete.json"))
            z.write(JSONObject().put("formato", FORMAT_PROJECT).put("version", 1).toString().toByteArray())
            z.closeEntry()
            for (name in listOf("proyecto.json", "informacion.txt")) {
                val f = File(dir, name)
                if (f.exists()) {
                    z.putNextEntry(ZipEntry(name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                }
            }
            File(dir, "fotos").listFiles()?.filter { it.isFile }?.forEach { f ->
                z.putNextEntry(ZipEntry("fotos/${f.name}")); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
        }
        return out
    }

    fun prepareProject(ctx: Context, uri: Uri): ProjectPackage {
        val tmp = File(ctx.cacheDir, "import_proj_${System.currentTimeMillis()}.zip")
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("No se pudo abrir el archivo")
        input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        try {
            ZipFile(tmp).use { z ->
                val meta = z.getEntry("paquete.json")
                if (meta == null) {
                    throw IllegalArgumentException(
                        if (z.getEntry("datos.json") != null)
                            "Este archivo es un paquete de mediciones: impórtalo desde dentro del proyecto (⬇ Importar)"
                        else "El archivo no es un proyecto de Ferrocarrilnaitor")
                }
                val m = JSONObject(z.getInputStream(meta).bufferedReader().readText())
                if (m.optString("formato") != FORMAT_PROJECT)
                    throw IllegalArgumentException("El archivo no es un proyecto de Ferrocarrilnaitor")
                val pe = z.getEntry("proyecto.json") ?: throw IllegalArgumentException("Falta proyecto.json")
                val o = JSONObject(z.getInputStream(pe).bufferedReader().readText())
                Project.fromJson(o)   // valida que se puede leer
                val photos = z.entries().asSequence().count { !it.isDirectory && it.name.startsWith("fotos/") }
                return ProjectPackage(tmp, o.getString("name"), o.getJSONArray("points").length(), photos)
            }
        } catch (e: Exception) {
            tmp.delete()
            throw if (e is IllegalArgumentException) e
            else IllegalArgumentException("El archivo no es un proyecto válido")
        }
    }

    /** Crea el proyecto en Documents/Ferrocarrilnaitor/Humanos/<nombre> y extrae sus fotos. */
    fun importProject(pkg: ProjectPackage, newName: String): File {
        val clean = Storage.sanitize(newName)
        val dir = File(Storage.root, clean)
        require(clean.isNotEmpty() && !dir.exists()) { "Ya existe un proyecto con ese nombre" }
        try {
            dir.mkdirs()
            ZipFile(pkg.file).use { z ->
                val o = JSONObject(z.getInputStream(z.getEntry("proyecto.json")).bufferedReader().readText())
                o.put("name", clean)
                val photosDir = File(dir, "fotos")
                z.entries().asSequence().filter { !it.isDirectory && it.name.startsWith("fotos/") }.forEach { e ->
                    photosDir.mkdirs()
                    // solo el nombre del archivo, nunca rutas del zip
                    z.getInputStream(e).use { i -> File(photosDir, File(e.name).name).outputStream().use { i.copyTo(it) } }
                }
                Storage.save(dir, Project.fromJson(o))
            }
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
        pkg.file.delete()
        return dir
    }

    fun discardProject(pkg: ProjectPackage) { pkg.file.delete() }

    fun shareZip(ctx: Context, file: File, title: String) {
        runCatching {
            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(send, title))
        }.onFailure {
            Toast.makeText(ctx, "Guardado en exportaciones/${file.name}, pero no se pudo abrir compartir",
                Toast.LENGTH_LONG).show()
        }
    }
}
