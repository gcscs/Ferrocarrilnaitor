package com.ferrocarrilnaitor

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = Color(0xFF90CAF9))
                else lightColorScheme(primary = Color(0xFF1565C0))
            ) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) { App(tick) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++   // refresca permisos y lista de proyectos (por si se borraron desde el explorador)
    }
}

sealed class Screen {
    object Modules : Screen()
    object Humanos : Screen()
    object Wizard : Screen()
    class Proj(val h: ProjectHolder) : Screen()
    class Cam(val h: ProjectHolder) : Screen()
    class Pt(val h: ProjectHolder, val id: String) : Screen()
    class Exp(val h: ProjectHolder) : Screen()
    class Imp(val h: ProjectHolder, val prep: Share.Prepared) : Screen()
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(Storage.hasAccess(ctx)) }
    LaunchedEffect(tick) { access = Storage.hasAccess(ctx) }
    if (!access) {
        PermissionScreen { access = Storage.hasAccess(ctx) }
        return
    }
    var screen by remember { mutableStateOf<Screen>(Screen.Modules) }
    val scope = rememberCoroutineScope()
    var importTarget by remember { mutableStateOf<ProjectHolder?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val target = importTarget
        if (uri != null && target != null) {
            Toast.makeText(ctx, "Leyendo paquete…", Toast.LENGTH_SHORT).show()
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { Share.prepare(ctx, target, uri) } }
                res.onSuccess { screen = Screen.Imp(target, it) }
                    .onFailure { Toast.makeText(ctx, it.message ?: "No se pudo leer el paquete", Toast.LENGTH_LONG).show() }
            }
        }
    }
    when (val s = screen) {
        Screen.Modules -> ModulesScreen { screen = Screen.Humanos }
        Screen.Humanos -> HumanosScreen(tick,
            onBack = { screen = Screen.Modules },
            onNew = { screen = Screen.Wizard },
            onOpen = { screen = Screen.Proj(it) })
        Screen.Wizard -> WizardScreen(
            onBack = { screen = Screen.Humanos },
            onCreated = { screen = Screen.Proj(it) })
        is Screen.Proj -> ProjectScreen(s.h,
            onBack = { screen = Screen.Humanos },
            onCamera = { screen = Screen.Cam(s.h) },
            onPoint = { screen = Screen.Pt(s.h, it) },
            onExport = { screen = Screen.Exp(s.h) },
            onImport = { importTarget = s.h; picker.launch(arrayOf("*/*")) })
        is Screen.Exp -> ExportScreen(s.h) { screen = Screen.Proj(s.h) }
        is Screen.Imp -> ImportScreen(s.h, s.prep,
            onDone = { screen = Screen.Proj(s.h) },
            onCancel = { screen = Screen.Proj(s.h) })
        is Screen.Cam -> CameraFlow(s.h) { screen = Screen.Proj(s.h) }
        is Screen.Pt -> {
            val pt = s.h.project.points.firstOrNull { it.id == s.id }
            if (pt == null) screen = Screen.Proj(s.h)
            else PointScreen(s.h, pt) { screen = Screen.Proj(s.h) }
        }
    }
}

@Composable
fun PermissionScreen(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { onChanged() }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Ferrocarrilnaitor", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.padding(8.dp))
        Text("Necesita acceso a los archivos para guardar los proyectos en Documents/Ferrocarrilnaitor.")
        Spacer(Modifier.padding(8.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")))
            } else launcher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }) { Text("Conceder acceso") }
    }
}

@Composable
fun ModulesScreen(onHumanos: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("🚆 Ferrocarrilnaitor", style = MaterialTheme.typography.headlineMedium)
        Text("Elige un módulo", modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
        Card(Modifier.fillMaxWidth().clickable(onClick = onHumanos)) {
            Column(Modifier.padding(20.dp)) {
                Text("Humanos", style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
fun HumanosScreen(tick: Int, onBack: () -> Unit, onNew: () -> Unit, onOpen: (ProjectHolder) -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var projects by remember { mutableStateOf(Storage.listProjects()) }
    LaunchedEffect(tick) { projects = Storage.listProjects() }

    // importar un proyecto completo compartido por otro móvil
    var pending by remember { mutableStateOf<ProjectPackage?>(null) }
    var newName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            Toast.makeText(ctx, "Leyendo proyecto…", Toast.LENGTH_SHORT).show()
            scope.launch {
                val res = withContext(Dispatchers.IO) { runCatching { Share.prepareProject(ctx, uri) } }
                res.onSuccess { pending = it; newName = it.name }
                    .onFailure { Toast.makeText(ctx, it.message ?: "No se pudo leer el proyecto", Toast.LENGTH_LONG).show() }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Header("Humanos", onBack)
        Row(Modifier.fillMaxWidth().padding(16.dp)) {
            Button(onClick = onNew, modifier = Modifier.weight(1f)) { Text("+ Nuevo proyecto") }
            OutlinedButton(onClick = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.weight(1f).padding(start = 8.dp)) { Text("⬇ Importar proyecto") }
        }
        if (projects.isEmpty()) {
            Text("No hay proyectos en Documents/Ferrocarrilnaitor/Humanos", modifier = Modifier.padding(16.dp))
        }
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            items(projects, key = { it.path }) { dir ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(dir.name, style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f).clickable {
                                val p = Storage.load(dir)
                                if (p == null) Toast.makeText(ctx, "No se pudo leer el proyecto", Toast.LENGTH_SHORT).show()
                                else onOpen(ProjectHolder(dir, p))
                            }.padding(16.dp))
                        TextButton(onClick = {
                            Toast.makeText(ctx, "Preparando proyecto…", Toast.LENGTH_SHORT).show()
                            scope.launch {
                                val res = withContext(Dispatchers.IO) { runCatching { Share.exportProject(dir) } }
                                res.onSuccess { Share.shareZip(ctx, it, "Compartir proyecto") }
                                    .onFailure { Toast.makeText(ctx, "Error al exportar: ${it.message}", Toast.LENGTH_LONG).show() }
                            }
                        }) { Text("⬆ Exportar") }
                    }
                }
            }
        }
    }

    pending?.let { pkg ->
        val clean = Storage.sanitize(newName)
        val exists = clean.isNotEmpty() && File(Storage.root, clean).exists()
        AlertDialog(
            onDismissRequest = { if (!busy) { Share.discardProject(pkg); pending = null } },
            title = { Text("Importar proyecto") },
            text = {
                Column {
                    Text("«${pkg.name}»: ${pkg.points} puntos y ${pkg.photos} fotos.")
                    OutlinedTextField(newName, { newName = it }, singleLine = true,
                        label = { Text("Nombre del proyecto") }, isError = exists,
                        supportingText = { if (exists) Text("Ya existe un proyecto con ese nombre, cámbialo") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            },
            confirmButton = {
                TextButton(enabled = clean.isNotEmpty() && !exists && !busy, onClick = {
                    busy = true
                    scope.launch {
                        val res = withContext(Dispatchers.IO) { runCatching { Share.importProject(pkg, clean) } }
                        busy = false
                        res.onSuccess {
                            pending = null
                            projects = Storage.listProjects()
                            Toast.makeText(ctx, "Proyecto importado", Toast.LENGTH_LONG).show()
                        }.onFailure {
                            Toast.makeText(ctx, "Error al importar: ${it.message}", Toast.LENGTH_LONG).show()
                        }
                    }
                }) { Text(if (busy) "Importando…" else "Importar") }
            },
            dismissButton = {
                TextButton(enabled = !busy, onClick = { Share.discardProject(pkg); pending = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
fun Choice(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text)
    }
}

@Composable
fun WizardScreen(onBack: () -> Unit, onCreated: (ProjectHolder) -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    BackHandler { if (step == 0) onBack() else step-- }
    var name by remember { mutableStateOf("") }
    var ac by remember { mutableStateOf(Meter.SMP3) }
    var dc by remember { mutableStateOf(Meter.ETM) }
    var first by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf("") }
    var nd by remember { mutableStateOf("") }
    var ns by remember { mutableStateOf("") }
    var tried by remember { mutableStateOf(false) }
    var triedTypes by remember { mutableStateOf(false) }
    val types = remember { mutableStateMapOf<String, PointType>() }
    val ctx = LocalContext.current
    val clean = Storage.sanitize(name)
    val exists = clean.isNotEmpty() && File(Storage.root, clean).exists()
    val usesSmp = ac.mode == Mode.REGISTRO || dc.mode == Mode.REGISTRO
    val usesFolder = ac.mode == Mode.CHECK || dc.mode == Mode.CHECK
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    @Composable
    fun RegField() = OutlinedTextField(first, { first = it.filter(Char::isDigit) },
        label = { Text("Nº del primer registro SMP-3") }, keyboardOptions = num,
        isError = tried && first.isBlank(),
        supportingText = { if (tried && first.isBlank()) Text("Rellena el nº del primer registro") },
        singleLine = true, modifier = Modifier.fillMaxWidth().padding(start = 40.dp, bottom = 8.dp))

    @Composable
    fun FolderField() = OutlinedTextField(folder, { folder = it }, singleLine = true,
        label = { Text("Carpeta del PC donde se guardan los datos") },
        isError = tried && folder.isBlank(),
        supportingText = { if (tried && folder.isBlank()) Text("Rellena el nombre de la carpeta") },
        modifier = Modifier.fillMaxWidth().padding(start = 40.dp, bottom = 8.dp))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Nuevo proyecto  (${step + 1}/4)") { if (step == 0) onBack() else step-- }
        Column(Modifier.padding(16.dp)) {
            when (step) {
                0 -> {
                    Text("Nombre del proyecto")
                    OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (exists) Text("Ya existe un proyecto con ese nombre", color = MaterialTheme.colorScheme.error)
                    Button(onClick = { step = 1 }, enabled = clean.isNotEmpty() && !exists,
                        modifier = Modifier.padding(top = 12.dp)) { Text("Siguiente") }
                }
                1 -> {
                    Text("Instrumento para AC", fontWeight = FontWeight.Bold)
                    Choice("SMP-3 (nº de registro)", ac == Meter.SMP3) { ac = Meter.SMP3 }
                    if (ac == Meter.SMP3) RegField()
                    Choice("EHP-50F (check de medido)", ac == Meter.EHP50F) { ac = Meter.EHP50F }
                    if (ac == Meter.EHP50F) FolderField()

                    Text("Instrumento para DC", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                    Choice("SMP-3 (nº de registro)", dc == Meter.SMP3) { dc = Meter.SMP3 }
                    if (dc == Meter.SMP3) {
                        if (ac == Meter.SMP3) Text("Usa el mismo contador de registros que AC",
                            modifier = Modifier.padding(start = 40.dp, bottom = 8.dp))
                        else RegField()
                    }
                    Choice("ETM (valor manual en mT)", dc == Meter.ETM) { dc = Meter.ETM }

                    Button(onClick = {
                        tried = true
                        when {
                            usesSmp && first.toIntOrNull() == null ->
                                Toast.makeText(ctx, "Rellena el nº del primer registro", Toast.LENGTH_SHORT).show()
                            usesFolder && folder.isBlank() ->
                                Toast.makeText(ctx, "Rellena el nombre de la carpeta del PC", Toast.LENGTH_SHORT).show()
                            else -> step = 2
                        }
                    }, modifier = Modifier.padding(top = 12.dp)) { Text("Siguiente") }
                }
                2 -> {
                    OutlinedTextField(nd, { nd = it.filter(Char::isDigit) }, keyboardOptions = num, singleLine = true,
                        label = { Text("Puntos dinámicos (D)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(ns, { ns = it.filter(Char::isDigit) }, keyboardOptions = num, singleLine = true,
                        label = { Text("Puntos estacionarios (S)") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    val total = (nd.toIntOrNull() ?: 0) + (ns.toIntOrNull() ?: 0)
                    Button(enabled = total > 0, modifier = Modifier.padding(top = 12.dp),
                        onClick = { step = 3 }) { Text("Siguiente") }
                }
                else -> {
                    val ids = (1..(nd.toIntOrNull() ?: 0)).map { "D$it" } + (1..(ns.toIntOrNull() ?: 0)).map { "S$it" }
                    Text("Tipo de cada punto", fontWeight = FontWeight.Bold)
                    Text(PointType.values().joinToString("   ·   ") { t ->
                        "${t.label}: ${t.heights.joinToString(", ")} cm"
                    }, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(bottom = 8.dp))
                    ids.forEach { id ->
                        val sel = types[id]
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(id, Modifier.width(44.dp), fontWeight = FontWeight.Bold,
                                color = if (triedTypes && sel == null) MaterialTheme.colorScheme.error else Color.Unspecified)
                            PointType.values().forEach { t ->
                                val mod = Modifier.weight(1f).padding(horizontal = 2.dp)
                                val pad = PaddingValues(horizontal = 4.dp)
                                if (sel == t) Button(onClick = { types[id] = t }, modifier = mod, contentPadding = pad) {
                                    Text(t.label, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                                } else OutlinedButton(onClick = { types[id] = t }, modifier = mod, contentPadding = pad) {
                                    Text(t.label, maxLines = 1, style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                    Button(modifier = Modifier.padding(top = 12.dp), onClick = {
                        triedTypes = true
                        val missing = ids.count { types[it] == null }
                        if (missing > 0) {
                            Toast.makeText(ctx, "Falta definir el tipo de $missing puntos", Toast.LENGTH_SHORT).show()
                        } else {
                            val pts = ids.map { Point(it, types[it]!!) }.toMutableList()
                            val p = Project(
                                name = clean, acMeter = ac, dcMeter = dc,
                                initialSmpNext = first.toIntOrNull() ?: 1,
                                folder = if (usesFolder) folder.trim() else "",
                                created = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()),
                                points = pts)
                            val h = ProjectHolder(File(Storage.root, clean), p)
                            h.commit()
                            onCreated(h)
                        }
                    }) { Text("Crear proyecto") }
                }
            }
        }
    }
}

@Composable
fun ProjectScreen(h: ProjectHolder, onBack: () -> Unit, onCamera: () -> Unit, onPoint: (String) -> Unit,
                  onExport: () -> Unit, onImport: () -> Unit) {
    val p = h.project
    var notes by remember { mutableStateOf(p.generalNotes) }
    fun flush() { if (notes != p.generalNotes) { p.generalNotes = notes; h.commit() } }
    LaunchedEffect(notes) { if (notes != p.generalNotes) { delay(500); flush() } }
    BackHandler { flush(); onBack() }

    // incompletos primero (orden estable dentro de cada grupo)
    val sorted = p.points.sortedBy { it.complete(p) }
    val s = sorted.filter { !it.isD }
    val d = sorted.filter { it.isD }
    val total = p.points.sumOf { it.total }
    val done = p.points.sumOf { it.done(p) }

    Column(Modifier.fillMaxSize()) {
        Header(p.name) { flush(); onBack() }
        LazyColumn(Modifier.padding(horizontal = 12.dp)) {
            item {
                Text("AC: ${p.acMeter.label}   ·   DC: ${p.dcMeter.label}")
                Text("Mediciones: $done / $total")
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas generales") }, minLines = 2,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Button(onClick = { flush(); onCamera() }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text("📷  Cámara")
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                    OutlinedButton(onClick = { flush(); onExport() }, modifier = Modifier.weight(1f).padding(end = 4.dp)) {
                        Text("⬆ Exportar")
                    }
                    OutlinedButton(onClick = { flush(); onImport() }, modifier = Modifier.weight(1f).padding(start = 4.dp)) {
                        Text("⬇ Importar")
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text("Estacionarios (S)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Dinámicos (D)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                }
            }
            items(maxOf(s.size, d.size)) { i ->
                Row(Modifier.fillMaxWidth()) {
                    Box(Modifier.weight(1f)) {
                        s.getOrNull(i)?.let { pt -> PointCard(pt, p) { flush(); onPoint(pt.id) } }
                    }
                    Box(Modifier.weight(1f)) {
                        d.getOrNull(i)?.let { pt -> PointCard(pt, p) { flush(); onPoint(pt.id) } }
                    }
                }
            }
        }
    }
}

@Composable
fun PointCard(pt: Point, p: Project, onClick: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ok = pt.complete(p)
    val bg = if (ok) (if (dark) Color(0xFF1B5E20) else Color(0xFFC8E6C9))
    else (if (dark) Color(0xFF7F1D1D) else Color(0xFFFFCDD2))
    val acDone = pt.ac.count { it.isMeasured(p.acMeter) }
    val dcDone = pt.dc.count { it.isMeasured(p.dcMeter) }
    Card(
        modifier = Modifier.fillMaxWidth().padding(3.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(pt.id, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(pt.type.label, style = MaterialTheme.typography.bodySmall)
            Text("AC $acDone/${pt.ac.size}" + if (acDone == pt.ac.size) " ✔" else " ✘", style = MaterialTheme.typography.bodySmall)
            Text("DC $dcDone/${pt.dc.size}" + if (dcDone == pt.dc.size) " ✔" else " ✘", style = MaterialTheme.typography.bodySmall)
            Text("📷 ${pt.photos.size}" + (if (pt.photos.isEmpty()) " ✘" else "") + (if (pt.notes.isNotBlank()) "  📝" else ""),
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun PointScreen(h: ProjectHolder, pt: Point, onBack: () -> Unit) {
    var notes by remember { mutableStateOf(pt.notes) }
    fun flush() { if (notes != pt.notes) { pt.notes = notes; h.commit() } }
    BackHandler { flush(); onBack() }
    LaunchedEffect(notes) { if (notes != pt.notes) { delay(500); flush() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Punto ${pt.id} · ${pt.type.label}") { flush(); onBack() }
        Column(Modifier.padding(horizontal = 16.dp)) {
            OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, minLines = 3,
                modifier = Modifier.fillMaxWidth())
            pt.type.heights.forEachIndexed { i, cm ->
                Text("Altura $cm cm", style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(top = 16.dp))
                MeasureBlock("AC $cm cm", h.project.acMeter, pt.ac[i], h)
                MeasureBlock("DC $cm cm", h.project.dcMeter, pt.dc[i], h)
            }
            PhotosSection(h, pt)
        }
    }
}

@Composable
fun MeasureBlock(label: String, meter: Meter, m: Measure, h: ProjectHolder) {
    var confirmClear by remember { mutableStateOf(false) }
    val measured = m.isMeasured(meter)
    val dark = isSystemInDarkTheme()
    // verde = rellenado, rojo = pendiente (mismos colores que las tarjetas de punto)
    val bg = if (measured) (if (dark) Color(0xFF1B5E20) else Color(0xFFC8E6C9))
    else (if (dark) Color(0xFF7F1D1D) else Color(0xFFFFCDD2))
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.padding(12.dp)) {
            Text("$label · ${meter.label}   " + if (measured) "✔" else "✘ pendiente",
                style = MaterialTheme.typography.titleMedium)
            if (measured) {
                Text("✔ ${m.describe(meter)}", modifier = Modifier.padding(vertical = 4.dp))
                TextButton(onClick = { confirmClear = true }) { Text("Desmarcar") }
            } else {
                when (meter.mode) {
                    Mode.REGISTRO -> RegistroInput(m, h)
                    Mode.VALOR -> ValorInput(m, h)
                    Mode.CHECK -> Row(Modifier.clickable { m.done = true; h.commit() },
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = false, onCheckedChange = { m.done = true; h.commit() })
                        Text(if (h.project.folder.isBlank()) "Medido"
                        else "Medido (datos en la carpeta \"${h.project.folder}\" del PC)")
                    }
                }
            }
        }
    }
    if (confirmClear) DoubleConfirm(
        "¿Desmarcar la medición $label?", "Se perderá el registro/valor de este punto.",
        onConfirm = { m.clear(); confirmClear = false; h.commit() },
        onDismiss = { confirmClear = false })
}

/** Registro SMP-3 con − / +. La sugerencia es siempre el siguiente registro del proyecto. */
@Composable
fun RegistroInput(m: Measure, h: ProjectHolder) {
    val p = h.project
    var text by remember { mutableStateOf<String?>(null) }
    // al guardar el otro componente (si ambos usan SMP-3) la sugerencia pasa al siguiente valor
    LaunchedEffect(p.smpNext) { text = null }
    val shown = text ?: p.smpNext.toString()
    fun bump(delta: Int) {
        val cur = shown.toIntOrNull() ?: p.smpNext
        text = (cur + delta).coerceAtLeast(0).toString()
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
        OutlinedButton(onClick = { bump(-1) }, modifier = Modifier.size(48.dp),
            contentPadding = PaddingValues(0.dp)) { Text("−") }
        OutlinedTextField(shown, { text = it.filter(Char::isDigit) }, singleLine = true,
            label = { Text("Nº de registro") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
        OutlinedButton(onClick = { bump(1) }, modifier = Modifier.size(48.dp),
            contentPadding = PaddingValues(0.dp)) { Text("+") }
    }
    Button(enabled = shown.toIntOrNull() != null, modifier = Modifier.padding(top = 8.dp), onClick = {
        val n = shown.toInt()
        m.registro = n
        p.smpNext = n + 1
        h.commit()
    }) { Text("Guardar registro") }
}

/** Valor manual en mT (ETM). */
@Composable
fun ValorInput(m: Measure, h: ProjectHolder) {
    var t by remember { mutableStateOf("") }
    OutlinedTextField(t, { t = it.filter { c -> c.isDigit() || c == '.' || c == ',' || c == '-' } },
        singleLine = true, label = { Text("Valor (mT)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
    Button(enabled = t.replace(',', '.').toDoubleOrNull() != null, modifier = Modifier.padding(top = 8.dp), onClick = {
        m.valorMt = t.replace(',', '.').toDouble()
        h.commit()
    }) { Text("Guardar valor") }
}

@Composable
fun PhotosSection(h: ProjectHolder, pt: Point) {
    var viewing by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    Text("Fotos (${pt.photos.size})", style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    pt.photos.toList().chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth()) {
            row.forEach { n ->
                Photo(h.photoFile(n), 300,
                    Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clickable { viewing = n },
                    ContentScale.Crop)
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    viewing?.let { n ->
        val shared = h.project.points.filter { n in it.photos }.joinToString(", ") { it.id }
        AlertDialog(
            onDismissRequest = { viewing = null },
            text = {
                Column {
                    Photo(h.photoFile(n), 1400, Modifier.fillMaxWidth(), ContentScale.Fit)
                    Text("$n · puntos: $shared", modifier = Modifier.padding(top = 6.dp))
                }
            },
            confirmButton = { TextButton(onClick = { deleting = n; viewing = null }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { viewing = null }) { Text("Cerrar") } })
    }
    deleting?.let { n ->
        DoubleConfirm("¿Borrar la foto $n del punto ${pt.id}?",
            "Si la foto también está en otros puntos, solo se quitará de este.",
            onConfirm = { h.removePhoto(pt, n); deleting = null },
            onDismiss = { deleting = null })
    }
}
