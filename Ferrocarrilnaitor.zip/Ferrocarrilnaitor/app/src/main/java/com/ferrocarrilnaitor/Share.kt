package com.ferrocarrilnaitor

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Medición recibida en un paquete (comp = "AC" o "DC"). */
class InMeasure(val comp: String, val height: Int, val m: Measure)

class InPoint(val id: String, val type: PointType, val measures: List<InMeasure>, val photos: List<String>)

class ImportPackage(val file: File, val source: String, val ac: Meter, val dc: Meter, val points: List<InPoint>)

/** Medición que ya está rellenada aquí con un valor distinto al del paquete. */
class Conflict(
    val point: Point, val comp: String, val height: Int, val meter: Meter,
    val local: Measure, val incoming: Measure
) {
    var useIncoming by mutableStateOf(false)     // por defecto prevalece la local
    val key get() = "${point.id}|$comp|$height"
}

class ImportPlan(
    val newMeasures: Int,
    val newPhotos: Int,
    val conflicts: List<Conflict>,
    val skipped: List<String>
)

object Share {
    private const val FORMAT = "ferrocarrilnaitor-export"

    // ---------------------------------------------------------------- exportar

    /** Crea un zip con datos.json (mediciones rellenadas) y las fotos de los puntos seleccionados. */
    fun export(h: ProjectHolder, ids: Set<String>): File {
        val p = h.project
        val pts = p.points.filter { it.id in ids }
        val dir = File(h.dir, "exportaciones").also { it.mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val out = File(dir, "${p.name}_export_$stamp.zip")

        fun measures(pt: Point, list: List<Measure>, meter: Meter) = JSONArray().also { a ->
            list.forEachIndexed { i, m ->
                if (m.isMeasured(meter)) a.put(m.toJson().put("h", pt.type.heights[i]))
            }
        }

        val json = JSONObject().apply {
            put("formato", FORMAT)
            put("version", 1)
            put("proyecto", p.name)
            put("ac", p.acMeter.name)
            put("dc", p.dcMeter.name)
            put("exportado", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()))
            put("puntos", JSONArray().also { arr ->
                pts.forEach { pt ->
                    arr.put(JSONObject().apply {
                        put("id", pt.id)
                        put("tipo", pt.type.name)
                        put("ac", measures(pt, pt.ac, p.acMeter))
                        put("dc", measures(pt, pt.dc, p.dcMeter))
                        put("fotos", JSONArray(pt.photos.toList()))
                    })
                }
            })
        }

        ZipOutputStream(FileOutputStream(out)).use { z ->
            z.putNextEntry(ZipEntry("datos.json"))
            z.write(json.toString(2).toByteArray())
            z.closeEntry()
            pts.flatMap { it.photos }.distinct().forEach { name ->
                val f = h.photoFile(name)
                if (f.exists()) {
                    z.putNextEntry(ZipEntry("fotos/$name"))
                    f.inputStream().use { it.copyTo(z) }
                    z.closeEntry()
                }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- importar

    class Prepared(val pkg: ImportPackage, val plan: ImportPlan)

    /** Lee el paquete elegido y calcula qué se añadiría y qué entra en conflicto. */
    fun prepare(ctx: Context, h: ProjectHolder, uri: Uri): Prepared {
        val tmp = File(ctx.cacheDir, "import_${System.currentTimeMillis()}.zip")
        val input = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalArgumentException("No se pudo abrir el archivo")
        input.use { i -> tmp.outputStream().use { i.copyTo(it) } }
        try {
            val pkg = readPackage(tmp)
            return Prepared(pkg, plan(h, pkg))
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    private fun readPackage(file: File): ImportPackage {
        val o: JSONObject = try {
            ZipFile(file).use { z ->
                val e = z.getEntry("datos.json") ?: throw IllegalArgumentException("not-pkg")
                JSONObject(z.getInputStream(e).bufferedReader().readText())
            }
        } catch (e: Exception) {
            throw IllegalArgumentException("El archivo no es un paquete de Ferrocarrilnaitor")
        }
        if (o.optString("formato") != FORMAT)
            throw IllegalArgumentException("El archivo no es un paquete de Ferrocarrilnaitor")

        fun measures(arr: JSONArray?, comp: String): List<InMeasure> {
            val out = mutableListOf<InMeasure>()
            if (arr != null) for (i in 0 until arr.length()) {
                val m = arr.getJSONObject(i)
                out.add(InMeasure(comp, m.getInt("h"), Measure.fromJson(m)))
            }
            return out
        }

        val pts = mutableListOf<InPoint>()
        val arr = o.getJSONArray("puntos")
        for (i in 0 until arr.length()) {
            val po = arr.getJSONObject(i)
            val ph = mutableListOf<String>()
            po.optJSONArray("fotos")?.let { for (k in 0 until it.length()) ph.add(it.getString(k)) }
            pts.add(InPoint(
                id = po.getString("id"),
                type = PointType.valueOf(po.getString("tipo")),
                measures = measures(po.optJSONArray("ac"), "AC") + measures(po.optJSONArray("dc"), "DC"),
                photos = ph
            ))
        }
        return ImportPackage(
            file = file,
            source = o.optString("proyecto", "?"),
            ac = Meter.valueOf(o.getString("ac")),
            dc = Meter.valueOf(o.getString("dc")),
            points = pts
        )
    }

    private fun sha256(i: InputStream): String {
        val md = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(8192)
        while (true) { val n = i.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** hash del contenido -> nombre de la foto que ya existe en el proyecto */
    private fun localHashes(h: ProjectHolder): MutableMap<String, String> {
        val map = mutableMapOf<String, String>()
        File(h.dir, "fotos").listFiles()?.forEach { f ->
            if (f.isFile) runCatching { f.inputStream().use { map[sha256(it)] = f.name } }
        }
        return map
    }

    /** Puntos del paquete que existen aquí con el mismo tipo; el resto se descartan con motivo. */
    private fun matching(p: Project, pkg: ImportPackage, skipped: MutableList<String>): List<Pair<InPoint, Point>> {
        val out = mutableListOf<Pair<InPoint, Point>>()
        for (ip in pkg.points) {
            val lp = p.points.firstOrNull { it.id == ip.id }
            when {
                lp == null -> skipped.add("${ip.id}: no existe en este proyecto")
                lp.type != ip.type -> skipped.add(
                    "${ip.id}: es de otro tipo (aquí ${lp.type.label}, en el paquete ${ip.type.label})")
                else -> out.add(ip to lp)
            }
        }
        return out
    }

    private fun plan(h: ProjectHolder, pkg: ImportPackage): ImportPlan {
        val p = h.project
        if (pkg.ac != p.acMeter || pkg.dc != p.dcMeter) throw IllegalArgumentException(
            "El paquete usa otros instrumentos (AC ${pkg.ac.label}, DC ${pkg.dc.label}) " +
                    "y este proyecto usa AC ${p.acMeter.label}, DC ${p.dcMeter.label}")
        val skipped = mutableListOf<String>()
        val pairs = matching(p, pkg, skipped)
        val conflicts = mutableListOf<Conflict>()
        var newMeasures = 0
        for ((ip, lp) in pairs) for (im in ip.measures) {
            val idx = lp.type.heights.indexOf(im.height)
            if (idx < 0) continue
            val isAc = im.comp == "AC"
            val meter = if (isAc) p.acMeter else p.dcMeter
            val local = (if (isAc) lp.ac else lp.dc)[idx]
            if (!local.isMeasured(meter)) newMeasures++
            else if (!local.sameAs(im.m, meter)) conflicts.add(Conflict(lp, im.comp, im.height, meter, local, im.m))
        }
        // fotos nuevas = fotos del paquete cuyo contenido no está ya en el proyecto
        val hashes = localHashes(h)
        var newPhotos = 0
        ZipFile(pkg.file).use { z ->
            pairs.flatMap { it.first.photos }.distinct().forEach { name ->
                val e = z.getEntry("fotos/$name")
                if (e != null && z.getInputStream(e).use { sha256(it) } !in hashes) newPhotos++
            }
        }
        return ImportPlan(newMeasures, newPhotos, conflicts, skipped)
    }

    /** Aplica el paquete: mediciones nuevas, conflictos según lo elegido y fotos nuevas. */
    fun apply(h: ProjectHolder, prep: Prepared) {
        val p = h.project
        val pkg = prep.pkg
        val decisions = prep.plan.conflicts.associateBy { it.key }
        val pairs = matching(p, pkg, mutableListOf())

        for ((ip, lp) in pairs) for (im in ip.measures) {
            val idx = lp.type.heights.indexOf(im.height)
            if (idx < 0) continue
            val isAc = im.comp == "AC"
            val meter = if (isAc) p.acMeter else p.dcMeter
            val local = (if (isAc) lp.ac else lp.dc)[idx]
            if (!local.isMeasured(meter)) local.copyFrom(im.m)
            else decisions["${lp.id}|${im.comp}|${im.height}"]?.let { if (it.useIncoming) local.copyFrom(im.m) }
        }

        // fotos: se reutiliza la que ya exista con el mismo contenido; si no, se copia con nombre nuevo
        val hashes = localHashes(h)
        val refs = LinkedHashMap<String, MutableList<Point>>()
        for ((ip, lp) in pairs) ip.photos.forEach { refs.getOrPut(it) { mutableListOf() }.add(lp) }
        ZipFile(pkg.file).use { z ->
            for ((name, pts) in refs) {
                val e = z.getEntry("fotos/$name") ?: continue
                val hash = z.getInputStream(e).use { sha256(it) }
                var local = hashes[hash]
                if (local == null) {
                    p.photoCounter++
                    local = "foto_%04d_%s.jpg".format(p.photoCounter, pts.joinToString("-") { it.id })
                    val dest = h.photoFile(local)
                    dest.parentFile?.mkdirs()
                    z.getInputStream(e).use { i -> dest.outputStream().use { i.copyTo(it) } }
                    hashes[hash] = local
                }
                pts.forEach { if (local !in it.photos) it.photos.add(local) }
            }
        }
        h.commit()
        pkg.file.delete()
    }

    fun discard(prep: Prepared) { prep.pkg.file.delete() }
}
