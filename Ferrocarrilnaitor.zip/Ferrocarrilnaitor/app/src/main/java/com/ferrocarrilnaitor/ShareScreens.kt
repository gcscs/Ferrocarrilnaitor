package com.ferrocarrilnaitor

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Elegir los puntos cuyas fotos y mediciones se van a compartir. */
@Composable
fun ExportScreen(h: ProjectHolder, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = h.project
    val selected = remember { mutableStateListOf<String>() }
    var busy by remember { mutableStateOf(false) }
    val s = p.points.filter { !it.isD }
    val d = p.points.filter { it.isD }

    Column(Modifier.fillMaxSize()) {
        Header("Exportar", onBack)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            Text("Elige los puntos cuyas fotos y mediciones quieres compartir.")
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selected.clear(); selected.addAll(p.points.map { it.id }) }) { Text("Todos") }
                TextButton(onClick = { selected.clear() }) { Text("Ninguno") }
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Text("Estacionarios (S)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("Dinámicos (D)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            }
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) { s.forEach { SelectCell(it, selected) } }
                Column(Modifier.weight(1f)) { d.forEach { SelectCell(it, selected) } }
            }
        }
        Button(
            enabled = selected.isNotEmpty() && !busy,
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            onClick = {
                busy = true
                scope.launch {
                    val res = withContext(Dispatchers.IO) { runCatching { Share.export(h, selected.toSet()) } }
                    busy = false
                    res.onSuccess { file ->
                        runCatching {
                            val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "application/zip"
                                putExtra(Intent.EXTRA_STREAM, uri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            ctx.startActivity(Intent.createChooser(send, "Compartir mediciones"))
                        }.onFailure {
                            Toast.makeText(ctx, "Guardado en exportaciones/${file.name}, pero no se pudo abrir compartir",
                                Toast.LENGTH_LONG).show()
                        }
                    }.onFailure {
                        Toast.makeText(ctx, "Error al exportar: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        ) { Text(if (busy) "Preparando…" else "Exportar y compartir (${selected.size} puntos)") }
    }
}

@Composable
private fun SelectCell(pt: Point, selected: MutableList<String>) {
    val on = pt.id in selected
    val dark = isSystemInDarkTheme()
    val bg = if (on) (if (dark) Color(0xFF1E88E5) else Color(0xFF1565C0)) else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (on) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
    Card(
        modifier = Modifier.fillMaxWidth().padding(3.dp)
            .clickable { if (on) selected.remove(pt.id) else selected.add(pt.id) },
        colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
        border = if (on) BorderStroke(3.dp, Color(0xFFFFC107)) else null
    ) {
        Text((if (on) "✔  " else "") + "${pt.id} · ${pt.type.label}   📷${pt.photos.size}",
            modifier = Modifier.padding(12.dp),
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal)
    }
}

/** Resumen del paquete y, si hay conflictos, decisión de qué información prevalece. */
@Composable
fun ImportScreen(h: ProjectHolder, prep: Share.Prepared, onDone: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val plan = prep.plan
    var busy by remember { mutableStateOf(false) }
    val cancel = { Share.discard(prep); onCancel() }
    BackHandler(onBack = cancel)

    Column(Modifier.fillMaxSize()) {
        Header("Importar", cancel)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
            Text("Paquete del proyecto «${prep.pkg.source}»", fontWeight = FontWeight.Bold)
            Text("Mediciones nuevas: ${plan.newMeasures}")
            Text("Fotos nuevas: ${plan.newPhotos}")
            Text("Conflictos: ${plan.conflicts.size}")

            if (plan.skipped.isNotEmpty()) {
                Card(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Se ignorarán estos puntos:", fontWeight = FontWeight.Bold)
                        plan.skipped.forEach { Text("• $it") }
                    }
                }
            }

            if (plan.conflicts.isNotEmpty()) {
                Text("⚠ Estas mediciones ya están rellenadas aquí con un valor distinto. " +
                        "Elige qué información prevalece en cada una.",
                    modifier = Modifier.padding(top = 12.dp), color = MaterialTheme.colorScheme.error)
                Row(Modifier.padding(vertical = 4.dp)) {
                    OutlinedButton(onClick = { plan.conflicts.forEach { it.useIncoming = false } }) { Text("Todas las mías") }
                    OutlinedButton(onClick = { plan.conflicts.forEach { it.useIncoming = true } },
                        modifier = Modifier.padding(start = 8.dp)) { Text("Todas las importadas") }
                }
                plan.conflicts.forEach { c ->
                    Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${c.point.id} · ${c.comp} a ${c.height} cm", fontWeight = FontWeight.Bold)
                            Choice("Mantener la mía: ${c.local.describe(c.meter)}", !c.useIncoming) { c.useIncoming = false }
                            Choice("Usar la importada: ${c.incoming.describe(c.meter)}", c.useIncoming) { c.useIncoming = true }
                        }
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp)) {
            OutlinedButton(onClick = cancel) { Text("Cancelar") }
            Button(enabled = !busy, modifier = Modifier.weight(1f).padding(start = 8.dp), onClick = {
                busy = true
                scope.launch {
                    val res = withContext(Dispatchers.IO) { runCatching { Share.apply(h, prep) } }
                    busy = false
                    res.onSuccess {
                        Toast.makeText(ctx, "Importación terminada", Toast.LENGTH_LONG).show()
                        onDone()
                    }.onFailure {
                        Toast.makeText(ctx, "Error al importar: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }) { Text(if (busy) "Importando…" else "Importar") }
        }
    }
}
