package com.ferrocarrilnaitor

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import org.json.JSONObject
import java.io.File

object Storage {
    /** Documents/Ferrocarrilnaitor/Humanos */
    val root: File
        get() = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "Ferrocarrilnaitor/Humanos"
        )

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    fun sanitize(name: String) =
        name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").trim('.', ' ')

    /** Los proyectos son las subcarpetas que contienen proyecto.json (se borran desde el explorador). */
    fun listProjects(): List<File> {
        root.mkdirs()
        return root.listFiles { f -> f.isDirectory && File(f, "proyecto.json").exists() }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()
    }

    fun load(dir: File): Project? = runCatching {
        Project.fromJson(JSONObject(File(dir, "proyecto.json").readText()))
    }.getOrNull()

    fun save(dir: File, p: Project) {
        dir.mkdirs()
        File(dir, "proyecto.json").writeText(p.toJson().toString(2))
        File(dir, "informacion.txt").writeText(buildTxt(p))
    }

    private fun buildTxt(p: Project): String = buildString {
        appendLine("PROYECTO: ${p.name}")
        appendLine("Módulo: Humanos")
        appendLine("Creado: ${p.created}")
        appendLine()
        appendLine("INSTRUMENTOS")
        appendLine("  AC: ${p.acMeter.label}")
        appendLine("  DC: ${p.dcMeter.label}")
        if (p.usesFolder) appendLine("  Carpeta del PC: ${p.folder}")
        if (p.usesSmp) appendLine("  Siguiente registro SMP-3: ${p.smpNext}")
        appendLine()
        appendLine("NOTAS GENERALES")
        appendLine("  " + p.generalNotes.ifBlank { "-" }.replace("\n", "\n  "))
        appendLine()
        appendLine("PUNTOS: ${p.points.count { it.id.startsWith("D") }} dinámicos (D), " +
                "${p.points.count { it.id.startsWith("S") }} estacionarios (S)")
        for (pt in p.points) {
            appendLine()
            appendLine("[${pt.id}] ${pt.type.label}")
            pt.type.heights.forEachIndexed { i, hcm ->
                appendLine("  $hcm cm")
                appendLine("    AC (${p.acMeter.label}): " +
                        if (pt.ac[i].isMeasured(p.acMeter)) pt.ac[i].describe(p.acMeter) else "SIN MEDIR")
                appendLine("    DC (${p.dcMeter.label}): " +
                        if (pt.dc[i].isMeasured(p.dcMeter)) pt.dc[i].describe(p.dcMeter) else "SIN MEDIR")
            }
            appendLine("  Fotos: " + if (pt.photos.isEmpty()) "ninguna" else pt.photos.joinToString(", "))
            appendLine("  Notas: " + pt.notes.ifBlank { "-" })
        }
    }
}

/** Proyecto abierto (la UI se actualiza sola porque el modelo usa estado de Compose). */
class ProjectHolder(val dir: File, val project: Project) {
    fun commit() = Storage.save(dir, project)

    fun photoFile(name: String) = File(File(dir, "fotos"), name)

    /** Quita la foto del punto; el archivo se borra solo si ningún otro punto la usa. */
    fun removePhoto(p: Point, name: String) {
        p.photos.remove(name)
        if (project.points.none { name in it.photos }) photoFile(name).delete()
        commit()
    }
}
