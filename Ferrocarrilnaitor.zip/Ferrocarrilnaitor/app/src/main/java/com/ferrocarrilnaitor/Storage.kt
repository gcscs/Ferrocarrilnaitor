package com.ferrocarrilnaitor

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject
import java.io.File

object Storage {
    /** Documents/Ferrocarrilnaitor/Humanos */
    val root: File
        get() = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "Ferrocarrilnaitor/Humanos"
        )

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    fun sanitize(name: String) =
        name.trim().replace(Regex("[\\\\/:*?\"<>|]"), "_").trim('.', ' ')

    /** Los proyectos son las subcarpetas que contienen proyecto.json (se borran desde el explorador). */
    fun listProjects(): List<File> {
        root.mkdirs()
        return root.listFiles { f -> f.isDirectory && File(f, "proyecto.json").exists() }
            ?.sortedBy { it.name.lowercase() } ?: emptyList()
    }

    fun load(dir: File): Project? = runCatching {
        Project.fromJson(JSONObject(File(dir, "proyecto.json").readText()))
    }.getOrNull()

    fun save(dir: File, p: Project) {
        dir.mkdirs()
        File(dir, "proyecto.json").writeText(p.toJson().toString(2))
        File(dir, "informacion.txt").writeText(buildTxt(p))
    }

    private fun buildTxt(p: Project): String = buildString {
        appendLine("PROYECTO: ${p.name}")
        appendLine("Módulo: Humanos")
        appendLine("Creado: ${p.created}")
        appendLine()
        appendLine("INSTRUMENTOS")
        appendLine("  AC: ${p.acMeter.label}")
        appendLine("  DC: ${p.dcMeter.label}")
        if (p.usesEtm) appendLine("  Carpeta del PC (ETM): ${p.etmFolder}")
        if (p.usesSmp) appendLine("  Siguiente registro SMP-3: ${p.smpNext}")
        appendLine()
        appendLine("PUNTOS: ${p.points.count { it.id.startsWith("D") }} dinámicos (D), " +
                "${p.points.count { it.id.startsWith("S") }} estacionarios (S)")
        for (pt in p.points) {
            appendLine()
            appendLine("[${pt.id}]")
            appendLine("  AC (${p.acMeter.label}): " +
                    if (pt.ac.isMeasured(p.acMeter)) pt.ac.describe(p.acMeter) else "SIN MEDIR")
            appendLine("  DC (${p.dcMeter.label}): " +
                    if (pt.dc.isMeasured(p.dcMeter)) pt.dc.describe(p.dcMeter) else "SIN MEDIR")
            appendLine("  Fotos: " + if (pt.photos.isEmpty()) "ninguna" else pt.photos.joinToString(", "))
            appendLine("  Notas: " + pt.notes.ifBlank { "-" })
        }
    }
}

/** Proyecto abierto. `rev` cambia en cada guardado para forzar la recomposición. */
class ProjectHolder(val dir: File, val project: Project) {
    var rev by mutableIntStateOf(0)
        private set

    fun commit() {
        Storage.save(dir, project)
        rev++
    }

    fun photoFile(name: String) = File(File(dir, "fotos"), name)

    /** Quita la foto del punto; el archivo se borra solo si ningún otro punto la usa. */
    fun removePhoto(p: Point, name: String) {
        p.photos.remove(name)
        if (project.points.none { name in it.photos }) photoFile(name).delete()
        commit()
    }
}
