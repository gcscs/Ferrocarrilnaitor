package com.ferrocarrilnaitor

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(h: ProjectHolder, onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    val rev = h.rev
    val counts = h.project.points.associate { it.id to it.photos.size } // depende de rev
    var granted by remember {
        mutableStateOf(ctx.checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Se necesita permiso de cámara")
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Conceder permiso") }
            TextButton(onClick = onBack) { Text("Volver") }
        }
        return
    }

    val activity = ctx as ComponentActivity
    val selected = remember { mutableStateListOf<String>() }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var banner by remember { mutableStateOf<String?>(null) }
    val imageCapture = remember {
        ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build()
    }
    val previewView = remember { PreviewView(ctx) }

    DisposableEffect(Unit) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            provider.unbindAll()
            camera = provider.bindToLifecycle(activity, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { runCatching { future.get().unbindAll() } }
    }
    LaunchedEffect(banner) { if (banner != null) { delay(3000); banner = null } }

    val maxZoom = (camera?.cameraInfo?.zoomState?.value?.maxZoomRatio ?: 1f).coerceAtMost(10f)
    fun applyZoom(z: Float) {
        zoom = z.coerceIn(1f, maxZoom.coerceAtLeast(1f))
        camera?.cameraControl?.setZoomRatio(zoom)
    }

    fun takePhoto() {
        if (selected.isEmpty()) return
        val ids = selected.toList()
        h.project.photoCounter++
        val name = "foto_%04d_%s.jpg".format(h.project.photoCounter, ids.joinToString("-"))
        val file = h.photoFile(name)
        file.parentFile?.mkdirs()
        imageCapture.takePicture(
            ImageCapture.OutputFileOptions.Builder(file).build(),
            ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                    h.project.points.filter { it.id in ids }.forEach { it.photos.add(name) }
                    h.commit()
                    banner = "📷 Foto $name guardada en: ${ids.joinToString(", ")}"
                }
                override fun onError(e: ImageCaptureException) {
                    banner = "Error al sacar la foto: ${e.message}"
                }
            })
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { previewView },
            modifier = Modifier.fillMaxSize().pointerInput(maxZoom) {
                detectTransformGestures { _, _, z, _ -> applyZoom(zoom * z) }
            }
        )
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(8.dp)) {
            Text("← Atrás", color = Color.White)
        }
        banner?.let {
            Text(it, color = Color.White,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 56.dp, start = 16.dp, end = 16.dp)
                    .background(Color(0xCC2E7D32)).padding(10.dp))
        }
        Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
            .background(Color(0xAA000000)).padding(12.dp)) {
            if (maxZoom > 1.05f) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Zoom ${"%.1f".format(zoom)}x", color = Color.White)
                    Slider(value = zoom, onValueChange = { applyZoom(it) },
                        valueRange = 1f..maxZoom, modifier = Modifier.weight(1f).padding(start = 8.dp))
                }
            }
            Text("Puntos de esta foto (${selected.size} seleccionados)", color = Color.White,
                style = MaterialTheme.typography.labelMedium)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(h.project.points, key = { it.id }) { p ->
                    FilterChip(
                        selected = p.id in selected,
                        onClick = { if (p.id in selected) selected.remove(p.id) else selected.add(p.id) },
                        label = { Text("${p.id}  📷${counts[p.id] ?: 0}") }
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { selected.clear() }) { Text("Limpiar", color = Color.White) }
                Button(onClick = { takePhoto() }, enabled = selected.isNotEmpty()) { Text("📷  Sacar foto") }
                TextButton(onClick = { selected.clear(); selected.addAll(h.project.points.map { it.id }) }) {
                    Text("Todos", color = Color.White)
                }
            }
        }
    }
}
