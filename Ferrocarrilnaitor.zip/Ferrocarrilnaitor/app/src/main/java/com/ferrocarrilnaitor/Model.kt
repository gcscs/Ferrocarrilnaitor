package com.ferrocarrilnaitor

import org.json.JSONArray
import org.json.JSONObject

enum class Meter(val label: String) {
    SMP3("SMP-3"), EHP50F("EHP-50F"), ETM("ETM")
}

/** Medición de un componente (AC o DC) en un punto. */
class Measure(
    var done: Boolean = false,      // ETM: check de "medido"
    var registro: Int? = null,      // SMP-3: nº de registro
    var valorMt: Double? = null     // EHP-50F: valor en mT
) {
    fun isMeasured(m: Meter) = when (m) {
        Meter.SMP3 -> registro != null
        Meter.EHP50F -> valorMt != null
        Meter.ETM -> done
    }

    fun clear() { done = false; registro = null; valorMt = null }

    fun describe(m: Meter): String = when (m) {
        Meter.SMP3 -> "registro ${registro ?: "-"}"
        Meter.EHP50F -> "${valorMt ?: "-"} mT"
        Meter.ETM -> "medido"
    }

    fun toJson() = JSONObject().apply {
        put("done", done)
        registro?.let { put("registro", it) }
        valorMt?.let { put("valorMt", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = Measure(
            done = o.optBoolean("done", false),
            registro = if (o.has("registro")) o.getInt("registro") else null,
            valorMt = if (o.has("valorMt")) o.getDouble("valorMt") else null
        )
    }
}

class Point(
    val id: String,                 // D1, D2, S1...
    var notes: String = "",
    val ac: Measure = Measure(),
    val dc: Measure = Measure(),
    val photos: MutableList<String> = mutableListOf()
) {
    fun toJson() = JSONObject().apply {
        put("id", id)
        put("notes", notes)
        put("ac", ac.toJson())
        put("dc", dc.toJson())
        put("photos", JSONArray(photos))
    }

    companion object {
        fun fromJson(o: JSONObject): Point {
            val ph = mutableListOf<String>()
            o.optJSONArray("photos")?.let { for (i in 0 until it.length()) ph.add(it.getString(i)) }
            return Point(
                id = o.getString("id"),
                notes = o.optString("notes", ""),
                ac = Measure.fromJson(o.getJSONObject("ac")),
                dc = Measure.fromJson(o.getJSONObject("dc")),
                photos = ph
            )
        }
    }
}

class Project(
    val name: String,
    val acMeter: Meter,             // SMP3 o EHP50F
    val dcMeter: Meter,             // SMP3 o ETM
    var smpNext: Int,               // siguiente nº de registro SMP-3
    val etmFolder: String,          // carpeta del PC donde se guardan los datos ETM
    val created: String,
    val points: MutableList<Point>,
    var photoCounter: Int = 0
) {
    val usesSmp get() = acMeter == Meter.SMP3 || dcMeter == Meter.SMP3
    val usesEtm get() = dcMeter == Meter.ETM

    fun toJson() = JSONObject().apply {
        put("name", name)
        put("ac", acMeter.name)
        put("dc", dcMeter.name)
        put("smpNext", smpNext)
        put("etmFolder", etmFolder)
        put("created", created)
        put("photoCounter", photoCounter)
        put("points", JSONArray().also { a -> points.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val pts = mutableListOf<Point>()
            val a = o.getJSONArray("points")
            for (i in 0 until a.length()) pts.add(Point.fromJson(a.getJSONObject(i)))
            return Project(
                name = o.getString("name"),
                acMeter = Meter.valueOf(o.getString("ac")),
                dcMeter = Meter.valueOf(o.getString("dc")),
                smpNext = o.optInt("smpNext", 1),
                etmFolder = o.optString("etmFolder", ""),
                created = o.optString("created", ""),
                points = pts,
                photoCounter = o.optInt("photoCounter", 0)
            )
        }
    }
}
