package com.ferrocarrilnaitor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** Cómo se rellena una medición: nº de registro, valor manual en mT o simple check. */
enum class Mode { REGISTRO, VALOR, CHECK }

enum class Meter(val label: String, val mode: Mode) {
    SMP3("SMP-3", Mode.REGISTRO),
    EHP50F("EHP-50F", Mode.CHECK),
    ETM("ETM", Mode.VALOR)
}

/** Tipo de punto: define a qué alturas (cm) hay que medir AC y DC. */
enum class PointType(val label: String, val heights: List<Int>) {
    CABINA("Cabina", listOf(90, 150)),
    PASAJEROS("Pasajeros", listOf(30, 90, 150)),
    EXTERIOR("Exterior", listOf(50, 150, 250))
}

/** Medición de un componente (AC o DC) en un punto. Los campos son estado de Compose. */
class Measure(
    initialDone: Boolean = false,       // CHECK (EHP-50F)
    initialRegistro: Int? = null,       // REGISTRO (SMP-3)
    initialValorMt: Double? = null      // VALOR (ETM), en mT
) {
    var done by mutableStateOf(initialDone)
    var registro by mutableStateOf(initialRegistro)
    var valorMt by mutableStateOf(initialValorMt)

    fun isMeasured(m: Meter) = when (m.mode) {
        Mode.REGISTRO -> registro != null
        Mode.CHECK -> done
        Mode.VALOR -> valorMt != null
    }

    fun clear() { done = false; registro = null; valorMt = null }

    fun copyFrom(o: Measure) { done = o.done; registro = o.registro; valorMt = o.valorMt }

    /** ¿Misma información? (solo cuenta el campo que usa el instrumento) */
    fun sameAs(o: Measure, m: Meter) = when (m.mode) {
        Mode.REGISTRO -> registro == o.registro
        Mode.CHECK -> done == o.done
        Mode.VALOR -> valorMt == o.valorMt
    }

    fun describe(m: Meter): String = when (m.mode) {
        Mode.REGISTRO -> "registro ${registro ?: "-"}"
        Mode.CHECK -> "medido"
        Mode.VALOR -> "${valorMt ?: "-"} mT"
    }

    fun toJson() = JSONObject().apply {
        put("done", done)
        registro?.let { put("registro", it) }
        valorMt?.let { put("valorMt", it) }
    }

    companion object {
        fun fromJson(o: JSONObject) = Measure(
            initialDone = o.optBoolean("done", false),
            initialRegistro = if (o.has("registro")) o.getInt("registro") else null,
            initialValorMt = if (o.has("valorMt")) o.getDouble("valorMt") else null
        )
    }
}

class Point(
    val id: String,                     // D1, D2, S1...
    val type: PointType,
    initialNotes: String = "",
    // una medición por cada altura del tipo (mismo orden que type.heights)
    val ac: List<Measure> = type.heights.map { Measure() },
    val dc: List<Measure> = type.heights.map { Measure() },
    initialPhotos: List<String> = emptyList()
) {
    var notes by mutableStateOf(initialNotes)
    val photos = mutableStateListOf<String>().also { it.addAll(initialPhotos) }

    val isD get() = id.startsWith("D")

    /** Mediciones totales (AC + DC) y rellenadas */
    val total get() = ac.size + dc.size
    fun done(p: Project) = ac.count { it.isMeasured(p.acMeter) } + dc.count { it.isMeasured(p.dcMeter) }

    /** Completo: todas las alturas de AC y DC medidas y al menos una foto. */
    fun complete(p: Project) = done(p) == total && photos.isNotEmpty()

    fun toJson() = JSONObject().apply {
        put("id", id)
        put("type", type.name)
        put("notes", notes)
        put("ac", JSONArray().also { a -> ac.forEach { a.put(it.toJson()) } })
        put("dc", JSONArray().also { a -> dc.forEach { a.put(it.toJson()) } })
        put("photos", JSONArray(photos.toList()))
    }

    companion object {
        fun fromJson(o: JSONObject): Point {
            val type = PointType.valueOf(o.getString("type"))
            fun measures(key: String): List<Measure> {
                val arr = o.getJSONArray(key)
                return type.heights.indices.map { i ->
                    if (i < arr.length()) Measure.fromJson(arr.getJSONObject(i)) else Measure()
                }
            }
            val ph = mutableListOf<String>()
            o.optJSONArray("photos")?.let { for (i in 0 until it.length()) ph.add(it.getString(i)) }
            return Point(
                id = o.getString("id"),
                type = type,
                initialNotes = o.optString("notes", ""),
                ac = measures("ac"),
                dc = measures("dc"),
                initialPhotos = ph
            )
        }
    }
}

class Project(
    val name: String,
    val acMeter: Meter,                 // SMP3 o EHP50F
    val dcMeter: Meter,                 // SMP3 o ETM
    initialSmpNext: Int,                // siguiente nº de registro SMP-3
    val folder: String,                 // carpeta del PC (instrumento con check)
    val created: String,
    val points: MutableList<Point>,
    var photoCounter: Int = 0,
    initialGeneralNotes: String = ""
) {
    var smpNext by mutableIntStateOf(initialSmpNext)
    var generalNotes by mutableStateOf(initialGeneralNotes)

    val usesSmp get() = acMeter.mode == Mode.REGISTRO || dcMeter.mode == Mode.REGISTRO
    val usesFolder get() = acMeter.mode == Mode.CHECK || dcMeter.mode == Mode.CHECK

    fun toJson() = JSONObject().apply {
        put("name", name)
        put("ac", acMeter.name)
        put("dc", dcMeter.name)
        put("smpNext", smpNext)
        put("folder", folder)
        put("created", created)
        put("photoCounter", photoCounter)
        put("generalNotes", generalNotes)
        put("points", JSONArray().also { a -> points.forEach { a.put(it.toJson()) } })
    }

    companion object {
        fun fromJson(o: JSONObject): Project {
            val pts = mutableListOf<Point>()
            val a = o.getJSONArray("points")
            for (i in 0 until a.length()) pts.add(Point.fromJson(a.getJSONObject(i)))
            return Project(
                name = o.getString("name"),
                acMeter = Meter.valueOf(o.getString("ac")),
                dcMeter = Meter.valueOf(o.getString("dc")),
                initialSmpNext = o.optInt("smpNext", 1),
                folder = o.optString("folder", ""),
                created = o.optString("created", ""),
                points = pts,
                photoCounter = o.optInt("photoCounter", 0),
                initialGeneralNotes = o.optString("generalNotes", "")
            )
        }
    }
}
