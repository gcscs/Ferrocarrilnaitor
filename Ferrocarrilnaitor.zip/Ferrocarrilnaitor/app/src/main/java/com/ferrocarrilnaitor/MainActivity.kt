package com.ferrocarrilnaitor

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val dark = isSystemInDarkTheme()
            MaterialTheme(
                colorScheme = if (dark) darkColorScheme(primary = Color(0xFF90CAF9))
                else lightColorScheme(primary = Color(0xFF1565C0))
            ) {
                Surface(Modifier.fillMaxSize()) {
                    Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) { App(tick) }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++   // refresca permisos y lista de proyectos (por si se borraron desde el explorador)
    }
}

sealed class Screen {
    object Modules : Screen()
    object Humanos : Screen()
    object Wizard : Screen()
    class Proj(val h: ProjectHolder) : Screen()
    class Cam(val h: ProjectHolder) : Screen()
    class Pt(val h: ProjectHolder, val id: String) : Screen()
}

@Composable
fun App(tick: Int) {
    val ctx = LocalContext.current
    var access by remember { mutableStateOf(Storage.hasAccess(ctx)) }
    LaunchedEffect(tick) { access = Storage.hasAccess(ctx) }
    if (!access) {
        PermissionScreen { access = Storage.hasAccess(ctx) }
        return
    }
    var screen by remember { mutableStateOf<Screen>(Screen.Modules) }
    when (val s = screen) {
        Screen.Modules -> ModulesScreen { screen = Screen.Humanos }
        Screen.Humanos -> HumanosScreen(tick,
            onBack = { screen = Screen.Modules },
            onNew = { screen = Screen.Wizard },
            onOpen = { screen = Screen.Proj(it) })
        Screen.Wizard -> WizardScreen(
            onBack = { screen = Screen.Humanos },
            onCreated = { screen = Screen.Proj(it) })
        is Screen.Proj -> ProjectScreen(s.h,
            onBack = { screen = Screen.Humanos },
            onCamera = { screen = Screen.Cam(s.h) },
            onPoint = { screen = Screen.Pt(s.h, it) })
        is Screen.Cam -> CameraFlow(s.h) { screen = Screen.Proj(s.h) }
        is Screen.Pt -> {
            val pt = s.h.project.points.firstOrNull { it.id == s.id }
            if (pt == null) screen = Screen.Proj(s.h)
            else PointScreen(s.h, pt) { screen = Screen.Proj(s.h) }
        }
    }
}

@Composable
fun PermissionScreen(onChanged: () -> Unit) {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { onChanged() }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Ferrocarrilnaitor", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.padding(8.dp))
        Text("Necesita acceso a los archivos para guardar los proyectos en Documents/Ferrocarrilnaitor.")
        Spacer(Modifier.padding(8.dp))
        Button(onClick = {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${ctx.packageName}")))
            } else launcher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }) { Text("Conceder acceso") }
    }
}

@Composable
fun ModulesScreen(onHumanos: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("🚆 Ferrocarrilnaitor", style = MaterialTheme.typography.headlineMedium)
        Text("Elige un módulo", modifier = Modifier.padding(top = 4.dp, bottom = 16.dp))
        Card(Modifier.fillMaxWidth().clickable(onClick = onHumanos)) {
            Column(Modifier.padding(20.dp)) {
                Text("Humanos", style = MaterialTheme.typography.titleLarge)
            }
        }
    }
}

@Composable
fun HumanosScreen(tick: Int, onBack: () -> Unit, onNew: () -> Unit, onOpen: (ProjectHolder) -> Unit) {
    BackHandler(onBack = onBack)
    val ctx = LocalContext.current
    var projects by remember { mutableStateOf(Storage.listProjects()) }
    LaunchedEffect(tick) { projects = Storage.listProjects() }
    Column(Modifier.fillMaxSize()) {
        Header("Humanos", onBack)
        Button(onClick = onNew, modifier = Modifier.padding(16.dp).fillMaxWidth()) { Text("+ Nuevo proyecto") }
        if (projects.isEmpty()) {
            Text("No hay proyectos en Documents/Ferrocarrilnaitor/Humanos", modifier = Modifier.padding(16.dp))
        }
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            items(projects, key = { it.path }) { dir ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                    val p = Storage.load(dir)
                    if (p == null) Toast.makeText(ctx, "No se pudo leer el proyecto", Toast.LENGTH_SHORT).show()
                    else onOpen(ProjectHolder(dir, p))
                }) {
                    Text(dir.name, modifier = Modifier.padding(16.dp), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
fun Choice(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected = selected, onClick = onClick)
        Text(text)
    }
}

@Composable
fun WizardScreen(onBack: () -> Unit, onCreated: (ProjectHolder) -> Unit) {
    var step by remember { mutableIntStateOf(0) }
    BackHandler { if (step == 0) onBack() else step-- }
    var name by remember { mutableStateOf("") }
    var ac by remember { mutableStateOf(Meter.SMP3) }
    var dc by remember { mutableStateOf(Meter.ETM) }
    var first by remember { mutableStateOf("") }
    var folder by remember { mutableStateOf("") }
    var nd by remember { mutableStateOf("") }
    var ns by remember { mutableStateOf("") }
    var tried by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val clean = Storage.sanitize(name)
    val exists = clean.isNotEmpty() && File(Storage.root, clean).exists()
    val usesSmp = ac.mode == Mode.REGISTRO || dc.mode == Mode.REGISTRO
    val usesFolder = ac.mode == Mode.CHECK || dc.mode == Mode.CHECK
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    @Composable
    fun RegField() = OutlinedTextField(first, { first = it.filter(Char::isDigit) },
        label = { Text("Nº del primer registro SMP-3") }, keyboardOptions = num,
        isError = tried && first.isBlank(),
        supportingText = { if (tried && first.isBlank()) Text("Rellena el nº del primer registro") },
        singleLine = true, modifier = Modifier.fillMaxWidth().padding(start = 40.dp, bottom = 8.dp))

    @Composable
    fun FolderField() = OutlinedTextField(folder, { folder = it }, singleLine = true,
        label = { Text("Carpeta del PC donde se guardan los datos") },
        isError = tried && folder.isBlank(),
        supportingText = { if (tried && folder.isBlank()) Text("Rellena el nombre de la carpeta") },
        modifier = Modifier.fillMaxWidth().padding(start = 40.dp, bottom = 8.dp))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Nuevo proyecto  (${step + 1}/3)") { if (step == 0) onBack() else step-- }
        Column(Modifier.padding(16.dp)) {
            when (step) {
                0 -> {
                    Text("Nombre del proyecto")
                    OutlinedTextField(name, { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    if (exists) Text("Ya existe un proyecto con ese nombre", color = MaterialTheme.colorScheme.error)
                    Button(onClick = { step = 1 }, enabled = clean.isNotEmpty() && !exists,
                        modifier = Modifier.padding(top = 12.dp)) { Text("Siguiente") }
                }
                1 -> {
                    Text("Instrumento para AC", fontWeight = FontWeight.Bold)
                    Choice("SMP-3 (nº de registro)", ac == Meter.SMP3) { ac = Meter.SMP3 }
                    if (ac == Meter.SMP3) RegField()
                    Choice("EHP-50F (check de medido)", ac == Meter.EHP50F) { ac = Meter.EHP50F }
                    if (ac == Meter.EHP50F) FolderField()

                    Text("Instrumento para DC", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp))
                    Choice("SMP-3 (nº de registro)", dc == Meter.SMP3) { dc = Meter.SMP3 }
                    if (dc == Meter.SMP3) {
                        if (ac == Meter.SMP3) Text("Usa el mismo contador de registros que AC",
                            modifier = Modifier.padding(start = 40.dp, bottom = 8.dp))
                        else RegField()
                    }
                    Choice("ETM (valor manual en mT)", dc == Meter.ETM) { dc = Meter.ETM }

                    Button(onClick = {
                        tried = true
                        when {
                            usesSmp && first.toIntOrNull() == null ->
                                Toast.makeText(ctx, "Rellena el nº del primer registro", Toast.LENGTH_SHORT).show()
                            usesFolder && folder.isBlank() ->
                                Toast.makeText(ctx, "Rellena el nombre de la carpeta del PC", Toast.LENGTH_SHORT).show()
                            else -> step = 2
                        }
                    }, modifier = Modifier.padding(top = 12.dp)) { Text("Siguiente") }
                }
                else -> {
                    OutlinedTextField(nd, { nd = it.filter(Char::isDigit) }, keyboardOptions = num, singleLine = true,
                        label = { Text("Puntos dinámicos (D)") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(ns, { ns = it.filter(Char::isDigit) }, keyboardOptions = num, singleLine = true,
                        label = { Text("Puntos estacionarios (S)") },
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                    val total = (nd.toIntOrNull() ?: 0) + (ns.toIntOrNull() ?: 0)
                    Button(enabled = total > 0, modifier = Modifier.padding(top = 12.dp), onClick = {
                        val pts = mutableListOf<Point>()
                        for (i in 1..(nd.toIntOrNull() ?: 0)) pts.add(Point("D$i"))
                        for (i in 1..(ns.toIntOrNull() ?: 0)) pts.add(Point("S$i"))
                        val p = Project(
                            name = clean, acMeter = ac, dcMeter = dc,
                            initialSmpNext = first.toIntOrNull() ?: 1,
                            folder = if (usesFolder) folder.trim() else "",
                            created = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()),
                            points = pts)
                        val h = ProjectHolder(File(Storage.root, clean), p)
                        h.commit()
                        onCreated(h)
                    }) { Text("Crear proyecto") }
                }
            }
        }
    }
}

@Composable
fun ProjectScreen(h: ProjectHolder, onBack: () -> Unit, onCamera: () -> Unit, onPoint: (String) -> Unit) {
    val p = h.project
    var notes by remember { mutableStateOf(p.generalNotes) }
    fun flush() { if (notes != p.generalNotes) { p.generalNotes = notes; h.commit() } }
    LaunchedEffect(notes) { if (notes != p.generalNotes) { delay(500); flush() } }
    BackHandler { flush(); onBack() }

    // incompletos primero (orden estable dentro de cada grupo)
    val sorted = p.points.sortedBy { it.complete(p) }
    val s = sorted.filter { !it.isD }
    val d = sorted.filter { it.isD }
    val total = p.points.size * 2
    val done = p.points.sumOf { pt ->
        var n = 0
        if (pt.ac.isMeasured(p.acMeter)) n++
        if (pt.dc.isMeasured(p.dcMeter)) n++
        n
    }

    Column(Modifier.fillMaxSize()) {
        Header(p.name) { flush(); onBack() }
        LazyColumn(Modifier.padding(horizontal = 12.dp)) {
            item {
                Text("AC: ${p.acMeter.label}   ·   DC: ${p.dcMeter.label}")
                Text("Mediciones: $done / $total")
                OutlinedTextField(notes, { notes = it }, label = { Text("Notas generales") }, minLines = 2,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Button(onClick = { flush(); onCamera() }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                    Text("📷  Cámara")
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text("Estacionarios (S)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text("Dinámicos (D)", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                }
            }
            items(maxOf(s.size, d.size)) { i ->
                Row(Modifier.fillMaxWidth()) {
                    Box(Modifier.weight(1f)) {
                        s.getOrNull(i)?.let { pt -> PointCard(pt, p) { flush(); onPoint(pt.id) } }
                    }
                    Box(Modifier.weight(1f)) {
                        d.getOrNull(i)?.let { pt -> PointCard(pt, p) { flush(); onPoint(pt.id) } }
                    }
                }
            }
        }
    }
}

@Composable
fun PointCard(pt: Point, p: Project, onClick: () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ok = pt.complete(p)
    val bg = if (ok) (if (dark) Color(0xFF1B5E20) else Color(0xFFC8E6C9))
    else (if (dark) Color(0xFF7F1D1D) else Color(0xFFFFCDD2))
    val acOk = pt.ac.isMeasured(p.acMeter)
    val dcOk = pt.dc.isMeasured(p.dcMeter)
    Card(
        modifier = Modifier.fillMaxWidth().padding(3.dp).clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(Modifier.padding(10.dp)) {
            Text(pt.id, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("AC " + if (acOk) "✔ " + pt.ac.describe(p.acMeter) else "✘", style = MaterialTheme.typography.bodySmall)
            Text("DC " + if (dcOk) "✔ " + pt.dc.describe(p.dcMeter) else "✘", style = MaterialTheme.typography.bodySmall)
            Text("📷 ${pt.photos.size}" + (if (pt.photos.isEmpty()) " ✘" else "") + (if (pt.notes.isNotBlank()) "  📝" else ""),
                style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun PointScreen(h: ProjectHolder, pt: Point, onBack: () -> Unit) {
    var notes by remember { mutableStateOf(pt.notes) }
    fun flush() { if (notes != pt.notes) { pt.notes = notes; h.commit() } }
    BackHandler { flush(); onBack() }
    LaunchedEffect(notes) { if (notes != pt.notes) { delay(500); flush() } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Header("Punto ${pt.id}") { flush(); onBack() }
        Column(Modifier.padding(horizontal = 16.dp)) {
            OutlinedTextField(notes, { notes = it }, label = { Text("Notas") }, minLines = 3,
                modifier = Modifier.fillMaxWidth())
            MeasureBlock("AC", h.project.acMeter, pt.ac, h)
            MeasureBlock("DC", h.project.dcMeter, pt.dc, h)
            PhotosSection(h, pt)
        }
    }
}

@Composable
fun MeasureBlock(label: String, meter: Meter, m: Measure, h: ProjectHolder) {
    var confirmClear by remember { mutableStateOf(false) }
    val measured = m.isMeasured(meter)
    val dark = isSystemInDarkTheme()
    // verde = rellenado, rojo = pendiente (mismos colores que las tarjetas de punto)
    val bg = if (measured) (if (dark) Color(0xFF1B5E20) else Color(0xFFC8E6C9))
    else (if (dark) Color(0xFF7F1D1D) else Color(0xFFFFCDD2))
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp),
        colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.padding(12.dp)) {
            Text("$label · ${meter.label}   " + if (measured) "✔" else "✘ pendiente",
                style = MaterialTheme.typography.titleMedium)
            if (measured) {
                Text("✔ ${m.describe(meter)}", modifier = Modifier.padding(vertical = 4.dp))
                TextButton(onClick = { confirmClear = true }) { Text("Desmarcar") }
            } else {
                when (meter.mode) {
                    Mode.REGISTRO -> RegistroInput(m, h)
                    Mode.VALOR -> ValorInput(m, h)
                    Mode.CHECK -> Row(Modifier.clickable { m.done = true; h.commit() },
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = false, onCheckedChange = { m.done = true; h.commit() })
                        Text(if (h.project.folder.isBlank()) "Medido"
                        else "Medido (datos en la carpeta \"${h.project.folder}\" del PC)")
                    }
                }
            }
        }
    }
    if (confirmClear) DoubleConfirm(
        "¿Desmarcar la medición $label?", "Se perderá el registro/valor de este punto.",
        onConfirm = { m.clear(); confirmClear = false; h.commit() },
        onDismiss = { confirmClear = false })
}

/** Registro SMP-3 con − / +. La sugerencia es siempre el siguiente registro del proyecto. */
@Composable
fun RegistroInput(m: Measure, h: ProjectHolder) {
    val p = h.project
    var text by remember { mutableStateOf<String?>(null) }
    // al guardar el otro componente (si ambos usan SMP-3) la sugerencia pasa al siguiente valor
    LaunchedEffect(p.smpNext) { text = null }
    val shown = text ?: p.smpNext.toString()
    fun bump(delta: Int) {
        val cur = shown.toIntOrNull() ?: p.smpNext
        text = (cur + delta).coerceAtLeast(0).toString()
    }
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
        OutlinedButton(onClick = { bump(-1) }, modifier = Modifier.size(48.dp),
            contentPadding = PaddingValues(0.dp)) { Text("−") }
        OutlinedTextField(shown, { text = it.filter(Char::isDigit) }, singleLine = true,
            label = { Text("Nº de registro") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
        OutlinedButton(onClick = { bump(1) }, modifier = Modifier.size(48.dp),
            contentPadding = PaddingValues(0.dp)) { Text("+") }
    }
    Button(enabled = shown.toIntOrNull() != null, modifier = Modifier.padding(top = 8.dp), onClick = {
        val n = shown.toInt()
        m.registro = n
        p.smpNext = n + 1
        h.commit()
    }) { Text("Guardar registro") }
}

/** Valor manual en mT (ETM). */
@Composable
fun ValorInput(m: Measure, h: ProjectHolder) {
    var t by remember { mutableStateOf("") }
    OutlinedTextField(t, { t = it.filter { c -> c.isDigit() || c == '.' || c == ',' || c == '-' } },
        singleLine = true, label = { Text("Valor (mT)") },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = Modifier.fillMaxWidth().padding(top = 4.dp))
    Button(enabled = t.replace(',', '.').toDoubleOrNull() != null, modifier = Modifier.padding(top = 8.dp), onClick = {
        m.valorMt = t.replace(',', '.').toDouble()
        h.commit()
    }) { Text("Guardar valor") }
}

@Composable
fun PhotosSection(h: ProjectHolder, pt: Point) {
    var viewing by remember { mutableStateOf<String?>(null) }
    var deleting by remember { mutableStateOf<String?>(null) }
    Text("Fotos (${pt.photos.size})", style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 12.dp, bottom = 4.dp))
    pt.photos.toList().chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth()) {
            row.forEach { n ->
                Photo(h.photoFile(n), 300,
                    Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clickable { viewing = n },
                    ContentScale.Crop)
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    viewing?.let { n ->
        val shared = h.project.points.filter { n in it.photos }.joinToString(", ") { it.id }
        AlertDialog(
            onDismissRequest = { viewing = null },
            text = {
                Column {
                    Photo(h.photoFile(n), 1400, Modifier.fillMaxWidth(), ContentScale.Fit)
                    Text("$n · puntos: $shared", modifier = Modifier.padding(top = 6.dp))
                }
            },
            confirmButton = { TextButton(onClick = { deleting = n; viewing = null }) { Text("Borrar") } },
            dismissButton = { TextButton(onClick = { viewing = null }) { Text("Cerrar") } })
    }
    deleting?.let { n ->
        DoubleConfirm("¿Borrar la foto $n del punto ${pt.id}?",
            "Si la foto también está en otros puntos, solo se quitará de este.",
            onConfirm = { h.removePhoto(pt, n); deleting = null },
            onDismiss = { deleting = null })
    }
}
